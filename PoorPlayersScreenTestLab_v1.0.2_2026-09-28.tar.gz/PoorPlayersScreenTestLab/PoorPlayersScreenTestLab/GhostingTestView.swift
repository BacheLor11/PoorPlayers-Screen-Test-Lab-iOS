//
//  GhostingTestView.swift
//  LivePhotoLab
//
//  拖影测试（运动模糊测试）工具 —— 移植自「穷玩组屏幕工具箱」APK（已获授权）。
//
//  实现方式（v2.19.22 重写）：
//  不再走「视频编码 → AVPlayer」路线（iOS 硬件 H.264/HEVC 编码器约束极多，
//  反复出现 PlayerRemoteXPC err=-12860 黑屏，且无法在真机外定位）。
//  改为纯 Core Animation：把三档灰度滚动文字**预渲染成一张长图（filmstrip，含多份重复内容）**，
//  用 CALayer 承载，CADisplayLink 逐帧平移 contentLayer.frame.origin.y 实现无缝循环滚动。
//  - 完全不依赖视频编解码，不可能出现 -12860 / 黑屏。
//  - CADisplayLink 可显式申请 ProMotion：preferredFrameRateRange 设到 120Hz。
//    v2.19.28 关键补丁：Info.plist 增加 CADisableMinimumFrameDurationOnPhone ——
//    iPhone ProMotion 上不声明此 key，preferredFrameRateRange 会被系统 clamp 到 60Hz
//    （此前几版「实测始终 ~60」的真正原因）。声明后锁帧才真正生效。
//  - 每帧实测真实刷新率并显示，告别「到底几 Hz」的猜谜。

import SwiftUI
import UIKit
import CoreGraphics

// MARK: - 数据模型（取自 APK 反编译，已去除原品牌字样）

/// 三行滚动文字的统一内容（v2.19.31：不再各行不同文案，灰阶差异本身才是测试变量）
private let ghostUnifiedText = "用于检测显示器拖影表现，通过不同灰阶文字的移动轨迹来评估面板响应时间与过冲控制能力。请仔细观察文字移动时的边缘清晰度与拖尾程度，优质面板应保持画面干净利落。"

/// 文字灰阶组合（v2.19.31：设置面板可选，提供自由度；默认经典 255/200/128 即 APK 原版三档）
enum GhostGrayPreset: String, CaseIterable {
    case classic = "255/200/128"
    case mid     = "255/160/80"
    case high    = "255/128/32"
    case subtle  = "255/220/190"

    var grays: [Int] {
        switch self {
        case .classic: return [255, 200, 128]
        case .mid:     return [255, 160, 80]
        case .high:    return [255, 128, 32]
        case .subtle:  return [255, 220, 190]
        }
    }
}

enum GhostColorMode: String, CaseIterable {
    case white = "白"
    case red = "红"
    case green = "绿"
    case blue = "蓝"
}

enum GhostRefresh: String, CaseIterable {
    case native = "最高(原生)"
    case hz60 = "60Hz"
    case hz90 = "90Hz"
    case hz120 = "120Hz"

    /// 目标帧率。native 返回 0，表示「用屏幕原生最高」。
    var hz: Int {
        switch self {
        case .native: return 0
        case .hz60:   return 60
        case .hz90:   return 90
        case .hz120:  return 120
        }
    }
}

// MARK: - 滚动视图（CALayer + CADisplayLink）

final class GhostingScrollUIView: UIView {
    private let contentLayer = CALayer()
    private var displayLink: CADisplayLink?

    private var filmImage: CGImage?
    private var filmHPoints: CGFloat = 0   // 长图总高（点）
    private var blockHPoints: CGFloat = 0  // 单组内容重复高度（点），用于无缝循环
    private var offset: CGFloat = 0        // 当前滚动偏移（点），对 blockHPoints 取模
    private var lastTime: CFTimeInterval = 0
    private var measuredFps: Double = 0
    private var lastFpsReport: CFTimeInterval = 0
    private var lastReportedFps: Double = 0   // 上次实际上报值（变化阈值用）
    private var isRunning: Bool = false    // 播放状态镜像：仅在真正切换时才动时间基准

    // 参数
    var colorMode: GhostColorMode = .white
    var bgGray: Int = 10
    var speedPts: CGFloat = 200   // 滚动速度：点/秒
    var targetHz: Int = 0         // 0 = 原生最高
    var grays: [Int] = [255, 200, 128]  // 三行文字灰阶（v2.19.31 可选组合）
    var fpsReport: ((Double) -> Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        layer.masksToBounds = true   // 只显示可视区，滚动溢出被裁掉
        contentLayer.contentsGravity = .topLeft
        contentLayer.backgroundColor = UIColor(white: 10 / 255.0, alpha: 1).cgColor
        // 关闭隐式动画：逐帧改 frame 时若触发 position/bounds 动画会造成抖动（抽搐）
        contentLayer.actions = [
            "position": NSNull(),
            "bounds": NSNull(),
            "frame": NSNull(),
            "transform": NSNull()
        ]
        layer.addSublayer(contentLayer)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        if filmImage == nil { renderFilm() }
        updateScroll()
    }

    // MARK: 预渲染长图
    /// 用 UIGraphicsImageRenderer 绘制：其坐标系为 UIKit 风格（原点左上、y 向下），
    /// 与下方 rowYs（从上往下累加）完全吻合，文字才会落在正确位置。
    /// （旧版用裸 CGContext 时坐标系为左下原点、y 向上，NSAttributedString.draw 不自动翻转，
    ///  文字被画到图片底部且颠倒，而滚动窗口按「从上往下」取景，二者错位→文字永远在可视窗口外、整片空背景。）
    func renderFilm() {
        let w = bounds.width
        let h = bounds.height
        guard w > 0, h > 0 else { return }

        // 关键：用真实设备像素比渲染，且与下方 contentLayer 1:1 显示。
        // 旧版写死 s = min(scale, 2.0)，在 3x 屏上：图按 2x 渲染却铺在 3x 的 layer 上，
        // .topLeft 按 1:1 绘制 → 图只占左 2/3 宽（右侧露空＝「右边显示不全」），
        // 且 2x 图被塞进 3x 空间强制二次缩放 → 文字变糊。改用真实 scale 后 1:1 不缩放。
        let scale = UIScreen.main.scale
        let font = UIFont.systemFont(ofSize: 18, weight: .regular)
        let sidePad: CGFloat = 22
        let lineSpacing: CGFloat = 6
        let rowSpacing: CGFloat = 30
        let textW = max(1.0, w - 2 * sidePad)

        let paragraph = NSMutableParagraphStyle()
        paragraph.lineSpacing = lineSpacing
        paragraph.alignment = .left

        func textColor(gray: Int) -> UIColor {
            let b = CGFloat(gray) / 255.0
            switch colorMode {
            case .white: return UIColor(white: b, alpha: 1)
            case .red:   return UIColor(red: b, green: 0, blue: 0, alpha: 1)
            case .green: return UIColor(red: 0, green: b, blue: 0, alpha: 1)
            case .blue:  return UIColor(red: 0, green: 0, blue: b, alpha: 1)
            }
        }

        // 测量单组（3 段）内容高度（点）。v2.19.31：三行文字内容统一，灰阶来自所选组合
        let rows = grays.map { (gray: $0, text: ghostUnifiedText) }
        var rowHeights: [CGFloat] = []
        var rowYs: [CGFloat] = []
        var cum: CGFloat = 0
        for r in rows {
            let attrs: [NSAttributedString.Key: Any] = [
                .font: font,
                .foregroundColor: textColor(gray: r.gray),
                .paragraphStyle: paragraph
            ]
            let rect = NSAttributedString(string: r.text, attributes: attrs)
                .boundingRect(with: CGSize(width: textW, height: .greatestFiniteMagnitude),
                              options: [.usesLineFragmentOrigin], context: nil)
            let hh = ceil(rect.height)
            rowHeights.append(hh)
            rowYs.append(cum)
            cum += hh + rowSpacing
        }
        let blockH = cum                          // 单组高度（点）
        let needed = h + blockH                   // 图至少：屏高 + 一份（平移覆盖且回绕无缝）
        let nCopies = Int(ceil(needed / blockH)) + 1
        let filmH = CGFloat(nCopies) * blockH      // 长图总高（点）

        let format = UIGraphicsImageRendererFormat.default()
        format.scale = scale                       // 按设备像素比渲染 → 1:1 清晰
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: w, height: filmH), format: format)

        let image = renderer.image { ctx in
            // 背景填充
            UIColor(white: CGFloat(bgGray) / 255.0, alpha: 1).setFill()
            ctx.fill(CGRect(x: 0, y: 0, width: w, height: filmH))

            for c in 0..<nCopies {
                let baseY = CGFloat(c) * blockH
                for r in 0..<rows.count {
                    let attrs: [NSAttributedString.Key: Any] = [
                        .font: font,
                        .foregroundColor: textColor(gray: rows[r].gray),
                        .paragraphStyle: paragraph
                    ]
                    NSAttributedString(string: rows[r].text, attributes: attrs)
                        .draw(in: CGRect(x: sidePad, y: baseY + rowYs[r],
                                         width: textW, height: rowHeights[r]))
                }
            }
        }

        filmImage = image.cgImage
        // v2.19.29（修「字大 3 倍 + 右侧裁切 + 发糊」的核心）：
        // CALayer 显示 contents 的尺寸 = 图片像素尺寸 / contentsScale（默认 1）。
        // 我们按 3x 渲染长图，若不设 contentsScale，3 个像素被当成 3 个点铺出来
        // → 文字放大 3 倍、超出右边界被裁、非整数缩放发糊。设为设备像素比后 1:1 清晰。
        contentLayer.contentsScale = scale
        contentLayer.contents = filmImage
        blockHPoints = blockH
        filmHPoints = filmH
        updateScroll()
    }

    /// 无缝滚动：整张长图（已含多份重复内容）作为 contentLayer 的 contents，用 .topLeft
    /// 重力 1:1 显示；靠平移 contentLayer.frame.origin.y 实现滚动。offset 对「单组高度
    /// blockHPoints」取模，图在相邻份处内容相同 → 回绕时无可察觉跳变。
    private func updateScroll() {
        guard blockHPoints > 0, filmHPoints > 0 else { return }
        let yOff = -(offset.truncatingRemainder(dividingBy: blockHPoints))
        CATransaction.begin()
        CATransaction.setDisableActions(true)   // 双保险：杜绝逐帧改 frame 的隐式动画抖动
        contentLayer.frame = CGRect(x: 0, y: yOff, width: bounds.width, height: filmHPoints)
        CATransaction.commit()
    }

    // MARK: CADisplayLink
    private func ensureLink() {
        if displayLink == nil {
            let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
            applyFrameRate(link)
            link.add(to: .main, forMode: .common)
            displayLink = link
        }
    }

    /// 显式申请 ProMotion：把 preferredFrameRateRange 设到目标帧率。
    /// v2.19.29：全部**锁死**（minimum = maximum = preferred）。此前「最高(原生)」给的是
    /// 30~120 的宽范围，ProMotion 会在 120↔60 间自适应切换，节奏忽快忽慢正是「跳」的来源之一；
    /// 测试工具要求恒定帧率，不给系统降档空间。
    private func applyFrameRate(_ link: CADisplayLink) {
        let maxF = Float(UIScreen.main.maximumFramesPerSecond)
        if targetHz <= 0 {
            link.preferredFrameRateRange = CAFrameRateRange(minimum: maxF, maximum: maxF, preferred: maxF)
        } else {
            let v = min(Float(targetHz), maxF)
            link.preferredFrameRateRange = CAFrameRateRange(minimum: v, maximum: v, preferred: v)
        }
    }

    func setPlaying(_ playing: Bool) {
        ensureLink()
        // v2.19.28（修「行数跳变」）：只在播放状态**真正切换**时才动时间基准。
        // updateUIView 会周期性调用本方法——若每次都重置 lastTime，会在 dt 上制造周期性跳变；
        // 但若完全不重置，暂停恢复后首帧 dt 高达暂停时长，钳制保护会产生一次可察觉的位置跳变
        //（旧钳制值 1/60s × 速度 960 ≈ 16pt ≈ 一行文字 → 观感正是「跳一行」）。
        // 状态切换瞬间把 lastTime 设为当前时刻：恢复后首帧 dt 即真实帧间隔，无任何跳变。
        guard playing != isRunning else {
            displayLink?.isPaused = !playing
            return
        }
        isRunning = playing
        displayLink?.isPaused = !playing
        if playing { lastTime = CACurrentMediaTime() }
    }

    func updateParams(colorMode: GhostColorMode, bgGray: Int, speedPts: CGFloat, targetHz: Int, grays: [Int]) {
        let needRerender = (colorMode != self.colorMode) || (bgGray != self.bgGray) || (grays != self.grays)
        self.colorMode = colorMode
        self.bgGray = bgGray
        self.speedPts = speedPts
        self.grays = grays
        if targetHz != self.targetHz {
            self.targetHz = targetHz
            if let link = displayLink { applyFrameRate(link) }
        }
        if needRerender { renderFilm() }
    }

    @objc private func tick(_ link: CADisplayLink) {
        let t = CACurrentMediaTime()
        var dt = t - lastTime
        lastTime = t
        if dt <= 0 { return }
        // 卡顿保护（v2.19.28 收紧）：正常帧 dt ≤ 1/60s；超过 0.2s 一定是异常
        // （后台回前台/系统卡顿）。钳到一帧间隔（≤8pt 位移），比旧值 1/60s 更不易察觉。
        if dt > 0.2 { dt = 1.0 / 120.0 }

        offset += CGFloat(dt) * speedPts
        // 防止长时间运行后 offset 浮点精度下降：周期性回到单组周期内
        if offset > blockHPoints * 1000 {
            offset = offset.truncatingRemainder(dividingBy: blockHPoints)
        }
        updateScroll()

        let fps = 1.0 / dt
        measuredFps = (measuredFps == 0) ? fps : measuredFps * 0.9 + fps * 0.1
        // v2.19.29（修「还会跳」）：限频 0.3s→1s，且数值变化 ≥2Hz 才上报。
        // 每次上报都会触发 SwiftUI body 重算，打断主线程渲染节奏造成周期性顿跳；
        // 降频 + 阈值后，稳态下（如恒定 120Hz）SwiftUI 几乎不再刷新，滚动更顺。
        if t - lastFpsReport > 1.0 {
            let rounded = round(measuredFps * 10) / 10
            if abs(rounded - lastReportedFps) >= 2 {
                lastReportedFps = rounded
                lastFpsReport = t
                fpsReport?(rounded)
            }
        }
    }

    func invalidate() {
        displayLink?.invalidate()
        displayLink = nil
    }

    override func willMove(toWindow newWindow: UIWindow?) {
        super.willMove(toWindow: newWindow)
        if newWindow == nil {
            displayLink?.invalidate()
            displayLink = nil
        }
    }
}

// MARK: - UIViewRepresentable

struct GhostingScrollRepresentable: UIViewRepresentable {
    let colorMode: GhostColorMode
    let bgGray: Int
    let speedPts: CGFloat
    let targetHz: Int
    let grays: [Int]
    @Binding var isPlaying: Bool
    @Binding var measuredFps: Double

    func makeUIView(context: Context) -> GhostingScrollUIView {
        let v = GhostingScrollUIView()
        v.fpsReport = { val in
            Task { @MainActor in self.measuredFps = val }
        }
        v.updateParams(colorMode: colorMode, bgGray: bgGray, speedPts: speedPts, targetHz: targetHz, grays: grays)
        v.setPlaying(isPlaying)
        return v
    }

    func updateUIView(_ uiView: GhostingScrollUIView, context: Context) {
        uiView.updateParams(colorMode: colorMode, bgGray: bgGray, speedPts: speedPts, targetHz: targetHz, grays: grays)
        uiView.setPlaying(isPlaying)
    }
}

// MARK: - SwiftUI 视图

struct GhostingTestView: View {
    @State private var backgroundGray: Int = 10
    @State private var colorMode: GhostColorMode = .white
    @State private var scrollSpeed: Double = 960
    @State private var refreshMode: GhostRefresh = .native
    @State private var grayPreset: GhostGrayPreset = .classic
    @State private var isPlaying: Bool = true
    @State private var fullscreen: Bool = false
    @State private var measuredFps: Double = 0

    private let speedPresets: [Double] = [960, 1440, 2560, 3840]

    private var targetHz: Int { refreshMode.hz }
    private var maxFps: Int { UIScreen.main.maximumFramesPerSecond }

    var body: some View {
        ZStack {
            // 兜底背景（长图渲染前可见）
            Color(white: Double(backgroundGray) / 255.0)
                .ignoresSafeArea()

            GeometryReader { geo in
                GhostingScrollRepresentable(
                    colorMode: colorMode,
                    bgGray: backgroundGray,
                    speedPts: max(scrollSpeed, 1) * (min(geo.size.width, geo.size.height) / 1080.0),
                    targetHz: targetHz,
                    grays: grayPreset.grays,
                    isPlaying: $isPlaying,
                    measuredFps: $measuredFps
                )
                .ignoresSafeArea()
                .onTapGesture {
                    if fullscreen { withAnimation(.easeInOut(duration: 0.2)) { fullscreen = false } }
                }
            }
        }
        .ignoresSafeArea()
        .toolbar(fullscreen ? .hidden : .visible, for: .navigationBar)
        .toolbar(fullscreen ? .hidden : .visible, for: .tabBar)
        .statusBarHidden(fullscreen)
        .persistentSystemOverlays(fullscreen ? .hidden : .visible)
        // 全屏切换按钮：放进导航栏右上角，与「画面信号接收器」完全一致
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { fullscreen.toggle() }
                } label: {
                    Image(systemName: fullscreen ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right")
                }
            }
        }
        .onDisappear {
            UIApplication.shared.isIdleTimerDisabled = false
        }
        .onAppear {
            UIApplication.shared.isIdleTimerDisabled = true
        }
        // 控制卡片（与「画面信号接收器」同款样式）；进入全屏后整块隐藏
        .overlay(alignment: .bottom) {
            if !fullscreen {
                controlCard
                    .padding(.bottom, 16)
                    .padding(.horizontal, 16)
            }
        }
    }

    // MARK: 控制卡片
    private var controlCard: some View {
        VStack(spacing: 12) {
            HStack(spacing: 12) {
                Button {
                    isPlaying.toggle()
                } label: {
                    Label(isPlaying ? "暂停" : "继续",
                          systemImage: isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(Color.accentColor, in: RoundedRectangle(cornerRadius: 10))
                }
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("滚动速度：\(Int(scrollSpeed)) 点/秒")
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.8))
                Slider(value: $scrollSpeed, in: 120...4000, step: 10)
                    .disabled(isPlaying)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(speedPresets, id: \.self) { p in
                            Button { scrollSpeed = p } label: {
                                Text("\(Int(p))").font(.system(size: 13))
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 12).padding(.vertical, 6)
                                    .background(scrollSpeed == p ? Color.accentColor : Color.gray.opacity(0.4),
                                                in: RoundedRectangle(cornerRadius: 8))
                            }
                            .disabled(isPlaying)
                        }
                    }
                }
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("文字颜色")
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.8))
                Picker("文字颜色", selection: $colorMode) {
                    ForEach(GhostColorMode.allCases, id: \.self) { m in
                        Text(m.rawValue).tag(m)
                    }
                }
                .pickerStyle(.segmented)
                .disabled(isPlaying)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("文字灰阶（三行）")
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.8))
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(GhostGrayPreset.allCases, id: \.self) { p in
                            Button { grayPreset = p } label: {
                                Text(p.rawValue).font(.system(size: 13, weight: .semibold))
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 12).padding(.vertical, 6)
                                    .background(grayPreset == p ? Color.accentColor : Color.gray.opacity(0.4),
                                                in: RoundedRectangle(cornerRadius: 8))
                            }
                            .disabled(isPlaying)
                        }
                    }
                }
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("背景灰阶：\(backgroundGray)")
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.8))
                Slider(value: Binding(
                    get: { Double(backgroundGray) },
                    set: { backgroundGray = Int($0) }), in: 0...255, step: 1)
                    .disabled(isPlaying)
            }

            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text("刷新率（目标）：\(targetHz == 0 ? "原生最高" : "\(targetHz) fps")")
                        .font(.system(size: 12))
                        .foregroundColor(.white.opacity(0.8))
                    if isPlaying, measuredFps > 1 {
                        Text("实测 ≈ \(Int(measuredFps)) Hz")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(measuredFps >= 100 ? .green : .orange)
                    }
                }
                Picker("刷新率", selection: $refreshMode) {
                    ForEach(GhostRefresh.allCases, id: \.self) { m in
                        Text(m.rawValue).tag(m)
                    }
                }
                .pickerStyle(.segmented)
                .disabled(isPlaying)
                Text("本机最高支持 \(maxFps)Hz；已锁定所选帧率（禁止系统自适应降档），「实测」为真实刷新率。")
                    .font(.system(size: 10))
                    .foregroundColor(.white.opacity(0.55))
            }
        }
        .padding(14)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}
