//
//  SubpixelTestView.swift
//  LivePhotoLab
//
//  「次像素渲染测试」工具（v2.19.35 新增，移植自穷玩组屏幕测试工具箱，已获授权）
//
//  原版实现（SubpixelScreen.kt 反编译对照）：
//  黑底全屏居中一组白色图案，全部按【物理像素】绘制（Android 侧以 px/density 换算成 dp，
//  实际 1 图案单位 = 1 物理像素）：
//    1. LineGroups  27×8px  —— 3 竖线 + 3 横线（1px 宽、间隔 3px）+ 3 条 45° 对角线（5px 步进）
//    2. StarTriple  69×21px —— 3 颗米字星：圆心 (11,11)/(34,11)/(57,11)（组内坐标），
//                              8 方向（45° 间隔）× 半径 1..4 的 1×1px 点
//    3. PixelText   59×9px  —— 自带 5×7 点阵字体（字符集 P/S/D/A/H/I）显示 "PPS DASHI"，
//                              每点 1×1px，字距 2px、空格 3px
//  三段垂直排列、水平居中、间隔 2px，整体位图 69×42 物理像素。
//
//  iOS 移植：UIGraphicsImageRenderer 按屏幕物理像素出图（format.scale = 屏幕倍率），
//  每个图案单位精确落在 1 个物理像素上；显示用 Image + .interpolation(.none)
//  做 1/2/4/8× 整数倍最近邻放大，放大后依然是干净的方格，方便肉眼与放大镜观察。
//

import SwiftUI

struct SubpixelTestView: View {

    // MARK: 参数

    /// 显示放大倍数（相对物理像素的整数倍，nearest-neighbor 不插值）
    @State private var zoom: Double = 1
    @State private var fullscreen: Bool = false

    /// 放大后图案的点尺寸
    private var displaySize: CGSize {
        CGSize(width: SubpixelPattern.widthPx / UIScreen.main.scale * zoom,
               height: SubpixelPattern.heightPx / UIScreen.main.scale * zoom)
    }

    // MARK: 主体

    var body: some View {
        ZStack {
            Color.black
                .ignoresSafeArea()
                .contentShape(Rectangle())
                .onTapGesture {
                    if fullscreen { withAnimation(.easeInOut(duration: 0.2)) { fullscreen = false } }
                }

            // 图案（1 物理像素 = 1 图案单位）
            if let img = patternImage {
                Image(uiImage: img)
                    .interpolation(.none)
                    .resizable()
                    .frame(width: displaySize.width, height: displaySize.height)
            }

            if !fullscreen {
                VStack {
                    Spacer(minLength: 0)
                    controlCard
                        .padding(.horizontal, 12)
                        .padding(.bottom, 8)
                }
            }
        }
        .navigationTitle("次像素渲染测试")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(fullscreen ? .hidden : .visible, for: .navigationBar)
        .toolbar(fullscreen ? .hidden : .visible, for: .tabBar)
        .statusBarHidden(fullscreen)
        .persistentSystemOverlays(fullscreen ? .hidden : .visible)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { fullscreen.toggle() }
                } label: {
                    Image(systemName: fullscreen
                          ? "arrow.down.right.and.arrow.up.left"
                          : "arrow.up.left.and.arrow.down.right")
                }
            }
        }
        .onAppear { UIApplication.shared.isIdleTimerDisabled = true }
        .onDisappear { UIApplication.shared.isIdleTimerDisabled = false }
    }

    // MARK: 图案位图

    private var patternImage: UIImage? {
        SubpixelPattern.render(scale: UIScreen.main.scale)
    }

    // MARK: 控制面板

    private var controlCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            VStack(alignment: .leading, spacing: 8) {
                Text("放大倍数：\(Int(zoom))×")
                    .font(.caption)
                Picker("放大倍数", selection: $zoom) {
                    Text("1×").tag(1.0)
                    Text("2×").tag(2.0)
                    Text("4×").tag(4.0)
                    Text("8×").tag(8.0)
                }
                .pickerStyle(.segmented)
                Text("图案 69 × 42 物理像素，白线与白点均为 1 物理像素宽。"
                     + "1× 用于放大镜 / 微距观察次像素排列与抗锯齿；整数倍放大便于肉眼检查线条完整性。")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Divider().opacity(0.2)

            VStack(alignment: .leading, spacing: 6) {
                Label("看什么", systemImage: "eye")
                    .font(.subheadline)
                Text("· 竖线 / 横线 / 对角线：边缘是否锐利，有没有不该有的抗锯齿灰边\n"
                     + "· 米字星：8 个方向的斜线像素是否连续均匀\n"
                     + "· PPS DASHI 像素字：每个 1px 点是否独立可辨、次像素有无偏色")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(14)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}

// MARK: - 图案位图生成（物理像素级）

/// 按穷玩组原版 SubpixelScreen.kt 复刻的图案位图（69 × 42 物理像素）
private enum SubpixelPattern {

    static let widthPx: CGFloat = 69
    static let heightPx: CGFloat = 42

    /// 5×7 点阵字体（反编译自原版 PIXEL_FONT，字符集 P/S/D/A/H/I）
    private static let pixelFont: [Character: [(Int, Int)]] = [
        "P": [(0,0),(1,0),(2,0),(0,1),(3,1),(0,2),(3,2),(0,3),(1,3),(2,3),(0,4),(0,5),(0,6)],
        "S": [(1,0),(2,0),(0,1),(3,1),(1,2),(2,2),(3,3),(0,4),(1,5),(2,5)],
        "D": [(0,0),(1,0),(2,0),(0,1),(3,1),(0,2),(3,2),(0,3),(3,3),(0,4),(1,4),(2,4)],
        "A": [(1,0),(2,0),(0,1),(3,1),(0,2),(1,2),(2,2),(3,2),(0,3),(3,3),(0,4),(3,4),(0,5),(3,5),(0,6),(3,6)],
        "H": [(0,0),(3,0),(0,1),(3,1),(0,2),(3,2),(0,3),(1,3),(2,3),(3,3),(0,4),(3,4),(0,5),(3,5),(0,6),(3,6)],
        "I": [(0,0),(1,0),(2,0),(1,1),(1,2),(1,3),(1,4),(1,5),(0,6),(1,6),(2,6)],
    ]

    /// 生成位图。scale 传屏幕物理像素比（如 3.0），图案坐标一律以物理像素为单位。
    static func render(scale: CGFloat) -> UIImage? {
        guard scale > 0 else { return nil }
        let format = UIGraphicsImageRendererFormat()
        format.scale = scale          // 1pt = scale px → 位图正好 widthPx × heightPx
        format.opaque = true
        let size = CGSize(width: widthPx / scale, height: heightPx / scale)
        let renderer = UIGraphicsImageRenderer(size: size, format: format)

        return renderer.image { ctx in
            let c = ctx.cgContext
            // 黑底
            c.setFillColor(red: 0, green: 0, blue: 0, alpha: 1)
            c.fill(CGRect(origin: .zero, size: size))
            // 白色 1px 单元
            c.setFillColor(red: 1, green: 1, blue: 1, alpha: 1)

            // 物理像素坐标 → 点坐标
            func rect(_ x: Int, _ y: Int, _ w: Int = 1, _ h: Int = 1) {
                c.fill(CGRect(x: CGFloat(x) / scale, y: CGFloat(y) / scale,
                              width: CGFloat(w) / scale, height: CGFloat(h) / scale))
            }

            // ---- 1. 线组（组内 27×8px，组水平居中：offset x = (69-27)/2 = 21） ----
            let lineOffsetX = 21
            for i in 0..<3 {                                   // 竖线：1×8px，间隔 3px
                rect(lineOffsetX + i * 3, 0, 1, 8)
            }
            for i in 0..<3 {                                   // 横线：y = 0/3/6，长 8px，x=30 起
                rect(lineOffsetX + 9, i * 3, 8, 1)
            }
            for i in 0..<3 {                                   // 45° 对角线：从 (18+i*3, 0) 走 6 个像素
                for j in 0..<6 {
                    rect(lineOffsetX + 18 + i * 3 + j, j, 1, 1)
                }
            }

            // ---- 2. 米字星 ×3（offset y = 10；圆心组内 (11,11)/(34,11)/(57,11)） ----
            let starOffsetY = 10
            let centers = [11, 34, 57]
            for cx in centers {
                for k in 0..<8 {
                    let theta = Double(k) * .pi / 4
                    let dx = cos(theta), dy = sin(theta)
                    for r in 1...4 {                           // 半径 1..4 的 1px 点
                        let px = Int((Double(cx) + Double(r) * dx).rounded())
                        let py = Int((Double(starOffsetY + 11) + Double(r) * dy).rounded())
                        rect(px, py)
                    }
                }
            }

            // ---- 3. 像素文本 "PPS DASHI"（组内 59×9px，起点 x=1；组居中 offset x = 5） ----
            let textOffsetX = 5
            let textOffsetY = 33
            var penX = textOffsetX + 1
            for ch in "PPS DASHI" {
                if ch == " " {
                    penX += 3                                  // 空格 3px
                    continue
                }
                guard let dots = pixelFont[ch] else { continue }
                for (col, row) in dots {
                    rect(penX + col, textOffsetY + row)
                }
                penX += 7                                      // 字宽 5px + 字距 2px
            }
        }
    }
}
