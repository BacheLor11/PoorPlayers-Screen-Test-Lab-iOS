//
//  RGBTestView.swift
//  LivePhotoLab
//
//  「RGB 测试」工具（v2.19.36 新增，移植自穷玩组屏幕测试工具箱，已获授权）
//
//  原版（RgbTestScreenKt / RgbTestViewModel 反编译对照）三个模式：
//    1. WIDE_GAMUT 广色域        —— 屏幕左右各半：左半 Display P3、右半 sRGB，
//                                  各画 RGB(255,0,0)/(0,255,0)/(0,0,255) 三色横条
//                                  （原版标签「左P3 右sRGB」）。同一组数值在不同
//                                  色彩空间下显示颜色不同：P3 屏上左半明显更饱和，
//                                  sRGB 屏幕上两半看起来一样（P3 被映射回 sRGB）。
//    2. RGB_GAINMAP HDR 增益     —— RGB 三色横条 + 增益：左半 4×、右半 R1×/G2×/B3×
//                                  （原版标签「左4X 右1X/2X/3X」，Gainmap
//                                  ratioMin=1 / ratioMax=4 / gamma=1）。
//                                  SDR 环境下增益被钳制，左右一样（原版标签 SDR）。
//    3. GRAYSCALE_GRADIENT 极低灰阶截断 —— W/R/G/B 四竖列 0→30 的极暗渐变
//                                  （原版标签「W/R/G/B 0→30」），检查黑场附近的
//                                  低灰阶是否被截断（crushed blacks）。
//  渲染细节见 RGBBarsEDRView.swift（EDR 增益条）与本文件位图生成。
//

import SwiftUI
import CoreImage

struct RGBTestView: View {

    // MARK: 模式

    enum RGBTestMode: String, CaseIterable, Identifiable {
        case wideGamut = "广色域"
        case gainmap = "HDR 增益"
        case clipping = "极低灰阶截断"
        var id: String { rawValue }
    }

    // MARK: 状态

    @State private var mode: RGBTestMode = .wideGamut
    @State private var fullscreen: Bool = false
    @State private var statusText: String = ""
    @State private var showExport: Bool = false

    private var headroom: Double { UIScreen.main.currentEDRHeadroom }
    private var isEDRActive: Bool { headroom > 1.05 }

    // MARK: 主体

    var body: some View {
        ZStack {
            patternLayer
                .ignoresSafeArea()
                .contentShape(Rectangle())
                .onTapGesture {
                    if fullscreen { withAnimation(.easeInOut(duration: 0.2)) { fullscreen = false } }
                }

            if !fullscreen {
                VStack {
                    Spacer(minLength: 0)
                    controlCard
                        .padding(.horizontal, 12)
                        .padding(.bottom, 8)
                }
            }
        }
        .navigationTitle("RGB 测试")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(fullscreen ? .hidden : .visible, for: .navigationBar)
        .toolbar(fullscreen ? .hidden : .visible, for: .tabBar)
        .statusBarHidden(fullscreen)
        .persistentSystemOverlays(fullscreen ? .hidden : .visible)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { fullscreen.toggle() }
                } label: {
                    Image(systemName: fullscreen
                          ? "arrow.down.right.and.arrow.up.left"
                          : "arrow.up.left.and.arrow.down.right")
                }
            }
        }
        .sheet(isPresented: $showExport) { exportSheet }
        .onAppear { UIApplication.shared.isIdleTimerDisabled = true }
        .onDisappear { UIApplication.shared.isIdleTimerDisabled = false }
    }

    // MARK: 图案

    @ViewBuilder
    private var patternLayer: some View {
        switch mode {
        case .wideGamut:
            // 左 P3 右 sRGB：两张各自带 ICC 的位图并排，系统色彩管理分别处理
            HStack(spacing: 0) {
                if let p3 = Self.rgbBarsBitmap(p3: true) {
                    Image(uiImage: p3).resizable().frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                if let srgb = Self.rgbBarsBitmap(p3: false) {
                    Image(uiImage: srgb).resizable().frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            }
        case .gainmap:
            RGBBarsEDRView(gainL: SIMD3<Float>(repeating: 4), gainR: SIMD3<Float>(1, 2, 3))
        case .clipping:
            if let img = Self.clippingBitmap() {
                Image(uiImage: img)
                    .resizable()
                    .scaledToFill()
            }
        }
    }

    /// 原版右上角的小标签
    private var modeTag: String {
        switch mode {
        case .wideGamut: return "左P3 右sRGB"
        case .gainmap:   return isEDRActive ? "左4X 右1X/2X/3X" : "SDR"
        case .clipping:  return "W/R/G/B 0→30"
        }
    }

    // MARK: 控制面板

    private var controlCard: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                Picker("模式", selection: $mode) {
                    ForEach(RGBTestMode.allCases) { Text($0.rawValue).tag($0) }
                }
                .pickerStyle(.segmented)

                HStack(spacing: 6) {
                    Text("RGB · \(modeTag)")
                        .font(.caption.weight(.medium))
                    if mode == .gainmap {
                        Text("headroom \(headroom, specifier: "%.2f")×")
                            .font(.caption2)
                            .foregroundColor(isEDRActive ? .orange : .secondary)
                    }
                }

                explanation

                Button {
                    showExport = true
                } label: {
                    Label("导出图片", systemImage: "square.and.arrow.up")
                        .font(.subheadline.weight(.medium))
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)

                if !statusText.isEmpty {
                    Text(statusText)
                        .font(.caption2)
                        .foregroundColor(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding(14)
        }
        .frame(maxHeight: 320)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }

    private var explanation: some View {
        Group {
            switch mode {
            case .wideGamut:
                Text("同一组 RGB(255/0, 0/255, 0/255) 数值分别按 Display P3 与 sRGB 解释。"
                     + "广色域屏幕上左半明显更饱和，sRGB 屏幕上两半一样；若左半不饱和，说明当前显示链路没走广色域。")
            case .gainmap:
                Text("RGB 三色横条叠加增益：左半 R/G/B 全部 4 倍亮度，右半 R 1×、G 2×、B 3×。"
                     + "亮度超过当前 headroom 会被钳制，请把系统亮度调低以获得更大 headroom。")
            case .clipping:
                Text("白灰/红/绿/蓝四列从 0 到 30 的极暗渐变。靠近顶部能分出层次说明低灰阶没有截断；"
                     + "若大片纯黑分不出层次，说明黑场被压缩（crushed blacks）。")
            }
        }
        .font(.caption2)
        .foregroundColor(.secondary)
        .fixedSize(horizontal: false, vertical: true)
    }

    // MARK: 导出

    private var exportSheet: some View {
        NavigationStack {
            List {
                Section {
                    Button {
                        exportCurrent()
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(exportTitle)
                                .font(.body)
                            Text(exportSubtitle)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                } header: {
                    Text("导出当前模式图案")
                } footer: {
                    Text(statusText.isEmpty
                         ? "导出尺寸：\(Int(UIScreen.main.nativeBounds.width)) × \(Int(UIScreen.main.nativeBounds.height)) px"
                         : statusText)
                        .font(.caption2)
                }
            }
            .navigationTitle("导出 RGB 测试图")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") { showExport = false }
                }
            }
        }
    }

    private var exportTitle: String {
        switch mode {
        case .wideGamut: return "导出 P3 PNG（RGB 三色条，Display P3 色彩空间）"
        case .gainmap:   return "导出 HDR 图片（HEIC + Gain Map，ratioMax 4）"
        case .clipping:  return "导出 SDR 图片（PNG，W/R/G/B 0→30 渐变）"
        }
    }

    private var exportSubtitle: String {
        switch mode {
        case .wideGamut: return "内嵌 Display P3 ICC，广色域设备可查看超 sRGB 的饱和原色"
        case .gainmap:   return "复用「照片 HDR 拓展」的 Gain Map 封装，HDR 屏幕可见左 4× / 右 1×·2×·3×"
        case .clipping:  return "普通动态范围，按屏幕物理像素输出"
        }
    }

    private func exportCurrent() {
        switch mode {
        case .wideGamut: exportP3PNG()
        case .gainmap:   exportGainMapHEIC()
        case .clipping:  exportClippingPNG()
        }
    }

    /// 广色域导出：P3 色彩空间的 RGB 三色条 PNG（CGImage 自带 P3 ICC，PNG 序列化时保留）
    private func exportP3PNG() {
        guard let img = Self.rgbBarsBitmap(p3: true, size: UIScreen.main.nativeBounds.size),
              let data = img.pngData() else {
            statusText = "生成 P3 位图失败"
            return
        }
        save(data, name: "RGB_P3Bars", ext: "png")
    }

    /// HDR 增益导出：主图 sRGB RGB 条 + 彩色增益图（左白 / 右 (0,85,170)），ratioMax 4
    private func exportGainMapHEIC() {
        let native = UIScreen.main.nativeBounds.size
        let w = Int(native.width), h = Int(native.height)
        guard let base = Self.rgbBarsCGImage(p3: false, width: w, height: h) else {
            statusText = "生成主图失败"
            return
        }
        guard let gainCG = Self.gainMapCGImage(width: w, height: h) else {
            statusText = "生成增益图失败"
            return
        }
        // 主图统一到 sRGB（HEIF 不收 DeviceRGB）
        let space = CGColorSpace(name: CGColorSpace.sRGB)!
        var sdrCI = CIImage(cgImage: base)
        if let cs = sdrCI.colorSpace, !CFEqual(cs, space) {
            if let toWorking = sdrCI.matchedToWorkingSpace(from: cs),
               let matched = toWorking.matchedFromWorkingSpace(to: space) {
                sdrCI = matched
            }
        }
        let (data, diag) = HDRGainMapExporter.writeGainMapHEIC(
            sdr: sdrCI,
            gainMap: CIImage(cgImage: gainCG),
            colorSpace: space,
            maxHeadroom: 4.0,
            quality: 0.9)
        guard let data else { statusText = diag; return }
        statusText = diag
        save(data, name: "RGB_GainMap", ext: "heic")
    }

    /// 极低灰阶截断导出：W/R/G/B 四列 0→30 渐变 PNG
    private func exportClippingPNG() {
        guard let img = Self.clippingBitmap(size: UIScreen.main.nativeBounds.size),
              let data = img.pngData() else {
            statusText = "生成渐变位图失败"
            return
        }
        save(data, name: "RGB_Clipping", ext: "png")
    }

    private func save(_ data: Data, name: String, ext: String) {
        let stamp = DateFormatter()
        stamp.dateFormat = "yyyyMMdd_HHmmss"
        let fileName = "\(name)_\(stamp.string(from: Date())).\(ext)"
        Task { @MainActor in
            switch await ImageExporter.saveData(data, suggestedFileName: fileName) {
            case .success:
                statusText += "\n已保存 \(fileName)"
            case .failure(let err):
                statusText += "\n保存失败：\(err.localizedDescription)"
            }
        }
    }

    // MARK: 位图生成

    /// RGB 三色横条（上红/中绿/下蓝，各 1/3 高）。
    /// - p3 = true 时位图挂在 Display P3 色彩空间上：同样的 (255,0,0) 等数值按 P3 原色解释，
    ///   广色域屏上比 sRGB 半边明显更饱和 —— 这正是原版「左P3 右sRGB」对比的原理。
    private static func rgbBarsBitmap(p3: Bool,
                                      size: CGSize = UIScreen.main.nativeBounds.size) -> UIImage? {
        guard let cg = rgbBarsCGImage(p3: p3,
                                      width: Int(size.width), height: Int(size.height)) else { return nil }
        return UIImage(cgImage: cg)
    }

    private static func rgbBarsCGImage(p3: Bool, width: Int, height: Int) -> CGImage? {
        guard width > 0, height > 0 else { return nil }
        let space = p3
            ? (CGColorSpace(name: CGColorSpace.displayP3) ?? CGColorSpaceCreateDeviceRGB())
            : (CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB())
        guard let ctx = CGContext(data: nil,
                                  width: width, height: height,
                                  bitsPerComponent: 8, bytesPerRow: 0,
                                  space: space,
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
                                      | CGBitmapInfo.byteOrder32Big.rawValue) else { return nil }
        // CG 坐标原点在左下：红条画在 y ∈ [2h/3, h) 才显示为「顶部」
        let third = height / 3
        let bars: [(CGFloat, CGFloat, CGFloat, Int, Int)] = [
            (1, 0, 0, 2 * third, height - 2 * third),   // 红（顶）
            (0, 1, 0, third, third),                    // 绿（中）
            (0, 0, 1, 0, height - 2 * third),           // 蓝（底）
        ]
        for (r, g, b, y, hh) in bars {
            // ⚠️ 必须用显式 CGColor：setFillColor(red:green:blue:alpha:) 创建的是
            // DeviceRGB 颜色，set 进 P3 context 时会被色彩管理【转换】成 P3 里对应
            // sRGB 原色的编码值——那样左右两半就完全一样了（v2.19.36 实测踩坑）。
            // CGColor(colorSpace:components:) 的组件就是【该空间的编码值】，原样写入不转换。
            let color = CGColor(colorSpace: space, components: [r, g, b, 1])
                ?? CGColor(red: r, green: g, blue: b, alpha: 1)
            ctx.setFillColor(color)
            ctx.fill(CGRect(x: 0, y: y, width: width, height: hh))
        }
        return ctx.makeImage()
    }

    /// 增益图：左半白（ratio = ratioMax = 4），右半 (0, 85, 170)（R→1×、G→2×、B→3×）。
    /// 与原版 generateRgbGainmapBitmap 的增益位图逐值一致。
    private static func gainMapCGImage(width: Int, height: Int) -> CGImage? {
        let space = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
        guard let ctx = CGContext(data: nil,
                                  width: width, height: height,
                                  bitsPerComponent: 8, bytesPerRow: 0,
                                  space: space,
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
                                      | CGBitmapInfo.byteOrder32Big.rawValue) else { return nil }
        ctx.setFillColor(red: 1, green: 1, blue: 1, alpha: 1)
        ctx.fill(CGRect(x: 0, y: 0, width: width / 2, height: height))
        ctx.setFillColor(red: 0, green: 85 / 255.0, blue: 170 / 255.0, alpha: 1)
        ctx.fill(CGRect(x: width / 2, y: 0, width: width - width / 2, height: height))
        return ctx.makeImage()
    }

    /// 极低灰阶截断：W/R/G/B 四竖列，每列从顶 0 到底 30 的编码值线性渐变
    /// （原版 generateClippingBitmap：v = coerceIn(30 * y / h, 0, 255)，sRGB 编码域）。
    private static func clippingBitmap(size: CGSize = UIScreen.main.nativeBounds.size) -> UIImage? {
        let scale = UIScreen.main.scale
        let format = UIGraphicsImageRendererFormat()
        format.scale = scale
        format.opaque = true
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: size.width / scale,
                                                            height: size.height / scale),
                                               format: format)
        return renderer.image { ctx in
            let c = ctx.cgContext
            c.setFillColor(red: 0, green: 0, blue: 0, alpha: 1)
            c.fill(CGRect(origin: .zero, size: CGSize(width: size.width / scale,
                                                      height: size.height / scale)))

            let w = size.width / scale
            let h = size.height / scale
            let columnW = w / 4
            // CG 线性渐变在 sRGB 空间按分量（编码值）线性插值，与原版逐行 setPixels 语义一致
            let top = CGFloat(0) / 255.0
            let bottom = CGFloat(30) / 255.0
            let colors: [(CGFloat, CGFloat, CGFloat)] = [
                (1, 1, 1),   // W
                (1, 0, 0),   // R
                (0, 1, 0),   // G
                (0, 0, 1),   // B
            ]
            for (i, rgb) in colors.enumerated() {
                guard let gradient = CGGradient(colorSpace: c.colorSpace ?? CGColorSpaceCreateDeviceRGB(),
                                                colorComponents: [rgb.0 * top, rgb.1 * top, rgb.2 * top, 1,
                                                                  rgb.0 * bottom, rgb.1 * bottom, rgb.2 * bottom, 1],
                                                locations: [0, 1],
                                                count: 2) else { continue }
                c.saveGState()
                // ⚠️ drawLinearGradient 填充的是【整个当前裁剪区域】而不是一条窄带！
                // 不 clip 的话四次调用互相覆盖，最终整屏只剩最后一次的蓝色渐变
                // （v2.19.36/37 实测踩坑：用户看到整屏蓝色调）。必须逐列 clip。
                let x = CGFloat(i) * columnW
                c.clip(to: CGRect(x: x, y: 0, width: columnW + 0.01, height: h))
                // UIKit 坐标原点左上：y=0（顶）值 0，y=h（底）值 30
                c.drawLinearGradient(gradient,
                                     start: CGPoint(x: columnW * (CGFloat(i) + 0.5), y: 0),
                                     end: CGPoint(x: columnW * (CGFloat(i) + 0.5), y: h),
                                     options: [])
                c.restoreGState()
            }
        }
    }
}
