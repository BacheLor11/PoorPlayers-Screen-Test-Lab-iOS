//
//  UIKitHelpers.swift
//  ScreenTestLab
//
//  从「A宝的工具箱」Pickers.swift 迁移的通用辅助（ImageExporter 依赖）。
//

import UIKit

/// 找到当前最上层 ViewController（present 系统面板用：分享 / 文档选择器 / 保存面板等）。
@MainActor
func topViewController() -> UIViewController? {
    guard let scene = UIApplication.shared.connectedScenes
            .first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene,
          let window = scene.windows.first(where: { $0.isKeyWindow }) else { return nil }
    var top = window.rootViewController
    while let presented = top?.presentedViewController { top = presented }
    return top
}
