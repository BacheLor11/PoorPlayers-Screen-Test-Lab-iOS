//
//  ContentView.swift
//  PoorPlayersScreenTestLab
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            PoorPlayersToolboxView()
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        NavigationLink {
                            AboutView()
                        } label: {
                            Image(systemName: "info.circle")
                        }
                    }
                }
        }
    }
}

// MARK: - 关于

struct AboutView: View {

    private var version: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String) ?? "1.0.0"
    }
    private var build: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String) ?? "1"
    }

    var body: some View {
        List {
            Section {
                LabeledContent("版本", value: "\(version) (\(build))")
                LabeledContent("屏幕", value: screenText)
            } header: {
                Text("关于本机")
            }

            Section {
                Text("本工具箱由「A宝的工具箱」团队移植自安卓 App「穷玩组屏幕测试工具箱」，已获得原作者 PoorPlayers 穷玩组授权。")
                    .font(.caption)
                    .foregroundColor(.secondary)
                linkRow(icon: "person.2", label: "穷玩组 · 微博", url: URL(string: "https://weibo.com/u/7369143916")!)
                linkRow(icon: "play.tv", label: "穷玩组 · B站", url: URL(string: "https://b23.tv/J7HSKeG")!)
            } header: {
                Text("移植授权 · PoorPlayers 穷玩组")
            } footer: {
                Text("功能、图案协议与阈值均按原作复刻，仅用于显示调试向。")
            }

            Section {
                VStack(alignment: .leading, spacing: 6) {
                    Text("移植作者：A宝（知乎：昂首阔步）")
                        .font(.subheadline.weight(.medium))
                    Text("关注A宝喵，关注A宝谢谢喵 (=^･ω･^=)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                linkRow(icon: "text.book.closed", label: "知乎 · 昂首阔步", url: URL(string: "https://www.zhihu.com/people/ang-shou-kuo-bu-24")!)
                linkRow(icon: "book", label: "小红书 · MoTech", url: URL(string: "https://xhslink.cn/m/5EslDdKZoXd")!)
                linkRow(icon: "person.2", label: "微博", url: URL(string: "https://weibo.com/7516633331")!)
                linkRow(icon: "video", label: "抖音", url: URL(string: "https://v.douyin.com/XTEdVMxd7JM/")!)
                linkRow(icon: "play.tv", label: "B站", url: URL(string: "https://b23.tv/entru4E")!)
                linkRow(icon: "wrench.and.screwdriver", label: "酷安", url: URL(string: "http://www.coolapk.com/u/3987328")!)
                linkRow(icon: "cart", label: "什么值得买", url: URL(string: "https://zhiyou.m.smzdm.com/member/4935269722")!)
            } header: {
                Text("移植作者 · A宝")
            }
        }
        .navigationTitle("关于")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var screenText: String {
        let s = UIScreen.main
        let pts = s.bounds.size
        let px = s.nativeBounds.size
        return String(format: "%.0f × %.0f pt · %.0f × %.0f px · %.0fx",
                      pts.width, pts.height, px.width, px.height, s.scale)
    }

    private func linkRow(icon: String, label: String, url: URL) -> some View {
        Link(destination: url) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .frame(width: 22)
                Text(label)
                    .font(.subheadline)
                Spacer()
                Image(systemName: "arrow.up.right")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
    }
}
