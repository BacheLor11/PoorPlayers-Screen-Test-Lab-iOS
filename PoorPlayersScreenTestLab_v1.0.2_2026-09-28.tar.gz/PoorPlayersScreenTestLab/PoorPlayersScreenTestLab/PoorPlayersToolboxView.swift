//
//  PoorPlayersToolboxView.swift
//  LivePhotoLab
//
//  「穷玩组屏幕测试工具箱」— 由 PoorPlayers 穷玩组安卓原版移植而来（已获授权）
//  B 站主页：https://space.bilibili.com/326251695
//

import SwiftUI

/// 穷玩组屏幕测试工具箱（iOS 移植版）主页
///
/// 本模块的功能、图案协议与阈值均对照安卓原版复刻，授权自 PoorPlayers 穷玩组。
/// 原计划中的其余测试页（APL / HDR 扫描 / 运动 / 拖影 / RGB 色域 / 次像素 /
/// Ultra HDR / 均匀度）将在后续版本分批移植。
struct PoorPlayersToolboxView: View {

    private let authorURL = URL(string: "https://space.bilibili.com/326251695")!

    var body: some View {
        List {
            Section {
                attributionCard
            }

            // 三个工具不按类目分组，列表保持平铺
            Section {
                NavigationLink {
                    ResolveSignalReceiverView()
                } label: {
                    toolRow(icon: "antenna.radiowaves.left.and.right",
                            title: "画面信号接收器",
                            subtitle: "接收 CalMAN / ColourSpace 的 Resolve XML 指令并显示测试图案")
                }
                NavigationLink {
                    GhostingTestView()
                } label: {
                    toolRow(icon: "text.word.spacing",
                            title: "拖影测试",
                            subtitle: "不同灰度文字垂直滚动，观察边缘锐利度与拖尾/残影")
                }
                NavigationLink {
                    APLTestView()
                } label: {
                    toolRow(icon: "aspectratio",
                            title: "APL 测试",
                            subtitle: "屏幕正中渲染等比白矩形，尺寸 1%~100% 可调，可导出 SDR / HDR 图片")
                }
                NavigationLink {
                    UniformityTestView()
                } label: {
                    toolRow(icon: "rectangle.fill",
                            title: "均匀度测试",
                            subtitle: "全屏铺满单一灰阶（0~255 可调），检查背光不均、漏光与暗角")
                }
                NavigationLink {
                    SubpixelTestView()
                } label: {
                    toolRow(icon: "grid",
                            title: "次像素渲染测试",
                            subtitle: "1 物理像素级线组 / 米字星 / 像素字，检查次像素排列与锐利度")
                }
                NavigationLink {
                    RGBTestView()
                } label: {
                    toolRow(icon: "paintpalette",
                            title: "RGB 测试",
                            subtitle: "广色域对比 / HDR 增益条 / 极低灰阶截断，可导出 P3 PNG 与 Gain Map HEIC")
                }
                NavigationLink {
                    FpsFlickerView()
                } label: {
                    toolRow(icon: "speedometer",
                            title: "FPS Flicker",
                            subtitle: "锁定目标刷新率显示纯色灰度，支持多档刷新率定时自动轮换")
                }
            } footer: {
                Text("APL：白矩形始终与屏幕同比例，拖到与四周边距齐平即可读出屏幕有效显示区域。")
            }
        }
        .navigationTitle("穷玩组屏幕测试工具箱")
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: 子视图

    private var attributionCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: "hand.raised.fill")
                    .foregroundColor(.accentColor)
                // 「PoorPlayers穷玩组」为可点击链接，跳转至原作者 B 站主页
                HStack(spacing: 0) {
                    Text("感谢 ")
                    Link("PoorPlayers穷玩组", destination: authorURL)
                        .font(.body.weight(.medium))
                    Text(" 授权")
                }
            }
            Text("安卓原作「穷玩组屏幕测试工具箱」")
                .font(.caption)
                .foregroundColor(.secondary)
            Text("本模块按原作协议与算法在 iOS 端复刻，仅用于显示调试向。")
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 4)
    }

    private func toolRow(icon: String, title: String, subtitle: String) -> some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.accentColor.opacity(0.15))
                    .frame(width: 40, height: 40)
                Image(systemName: icon)
                    .font(.system(size: 20, weight: .medium))
                    .foregroundColor(.accentColor)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.body)
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}
