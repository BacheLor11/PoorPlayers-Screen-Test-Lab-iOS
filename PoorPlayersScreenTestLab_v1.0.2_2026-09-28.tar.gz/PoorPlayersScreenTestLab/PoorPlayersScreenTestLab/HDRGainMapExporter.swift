//
//  HDRGainMapExporter.swift
//  LivePhotoLab
//
//  HDR Gain Map 写出器（v2.19.32）
//
//  写入链路与「照片 HDR 拓展」工具完全一致：
//    CIImage(SDR 主图) + CIImage(增益图) → CIContext.writeHEIFRepresentation(.hdrGainMapImage)
//    + MakerApple 33/48 解码参数 + 8bit RGBA。
//  这里把它独立出来，供「照片 HDR 拓展」与「APL 测试」共用，避免两处各写一套。
//

import CoreImage
import UIKit

enum HDRGainMapExporter {

    /// 写一张带 Gain Map 的 HEIC。
    /// - 返回 (HEIC Data?, 诊断文案)；data 为 nil 时诊断即失败原因。
    static func writeGainMapHEIC(sdr: CIImage,
                                 gainMap: CIImage,
                                 colorSpace: CGColorSpace,
                                 maxHeadroom: Float = 5.0,
                                 quality: Float = 0.85,
                                 livePhotoIdentifier: String? = nil) -> (Data?, String) {
        let stops = log2(Double(maxHeadroom))
        var makerApple: [String: Any] = [:]
        switch stops {
        case let x where x >= 2.3:
            makerApple["33"] = 1.0
            makerApple["48"] = (3.0 - x) / 70.0
        case 1.8..<2.3:
            makerApple["33"] = 1.0
            makerApple["48"] = (2.30303 - stops) / 0.303
        case 1.6..<1.8:
            makerApple["33"] = 0.0
            makerApple["48"] = (1.80 - stops) / 20.0
        default:
            makerApple["33"] = 0.0
            makerApple["48"] = (1.60101 - stops) / 0.101
        }
        // 注入 Live Photo 资产标识（key "17"）——与配对视频一致才能通过系统校验（否则 3302）
        if let lpId = livePhotoIdentifier {
            makerApple["17"] = lpId
        }
        var props = sdr.properties
        props[kCGImagePropertyMakerAppleDictionary as String] = makerApple
        let sdrWithProps = sdr.settingProperties(props)

        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("edrgain_\(UUID().uuidString).heic")
        defer { try? FileManager.default.removeItem(at: url) }
        let ctx = CIContext()
        let options: [CIImageRepresentationOption: Any] = [
            .hdrGainMapImage: gainMap,
            kCGImageDestinationLossyCompressionQuality as CIImageRepresentationOption: quality,
        ]
        do {
            try ctx.writeHEIFRepresentation(of: sdrWithProps, to: url, format: .RGBA8,
                                            colorSpace: colorSpace,
                                            options: options)
            let data = try Data(contentsOf: url)
            return (data, Self.gainMapCheck(in: data))
        } catch {
            let nsErr = error as NSError
            let csInfo = "主图cs=\(colorSpace) 增益图cs=\(String(describing: gainMap.colorSpace))"
            return (nil, "HEIF 写入失败(\(nsErr.code))：\(error.localizedDescription)\n\(csInfo)")
        }
    }

    /// 生成「白矩形」增益图：矩形内 = 满增益(白)，矩形外 = 基础灰。
    /// 用于 APL 这类纯黑底 + 白矩形的图案——背景保持 gain=1（不被提亮），只有矩形亮起来。
    /// 增益图按 ISO 21496-1 以 sRGB 方式编码：base 线性值需经 sRGB 编码后写入。
    static func rectGainMap(width: Int, height: Int, rect: CGRect, base: CGFloat = 0.2) -> CIImage? {
        guard width > 0, height > 0 else { return nil }
        let space = CGColorSpace(name: CGColorSpace.sRGB)
            ?? CGColorSpaceCreateDeviceRGB()
        guard let ctx = CGContext(data: nil,
                                  width: width, height: height,
                                  bitsPerComponent: 8, bytesPerRow: 0,
                                  space: space,
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
                                      | CGBitmapInfo.byteOrder32Big.rawValue) else { return nil }
        // iOS 的 CGColor 无白色/灰色快捷构造，直接按上下文 sRGB 空间填组件值
        let gray = srgbEncode(base)
        ctx.setFillColor(red: CGFloat(gray), green: CGFloat(gray), blue: CGFloat(gray), alpha: 1)
        ctx.fill(CGRect(x: 0, y: 0, width: width, height: height))
        if rect.width > 0.5, rect.height > 0.5 {
            ctx.setFillColor(red: 1, green: 1, blue: 1, alpha: 1)
            ctx.fill(rect)
        }
        guard let cg = ctx.makeImage() else { return nil }
        return CIImage(cgImage: cg)
    }

    /// 与「照片 HDR 拓展」中的自检同款：检测输出 HEIC 是否真的带 Gain Map
    static func gainMapCheck(in data: Data) -> String {
        guard let src = CGImageSourceCreateWithData(data as CFData, nil) else {
            return "增益图：无法解析输出"
        }
        var hasIso = false
        if #available(iOS 18.0, *) {
            hasIso = CGImageSourceCopyAuxiliaryDataInfoAtIndex(src, 0, kCGImageAuxiliaryDataTypeISOGainMap) != nil
        }
        let hasHDR = CGImageSourceCopyAuxiliaryDataInfoAtIndex(src, 0, kCGImageAuxiliaryDataTypeHDRGainMap) != nil
        return hasIso ? "增益图：ISO Gain Map ✓（HDR 屏幕可查看效果）"
            : hasHDR ? "增益图：HDR Gain Map ✓（HDR 屏幕可查看效果）"
            : "增益图：未检出（设备可能不支持生成）"
    }

    /// 线性 → sRGB 编码（与 PhotoEDRView 增益图 kernel 中的编码式一致）
    private static func srgbEncode(_ v: CGFloat) -> CGFloat {
        v < 0.018 ? v * 4.5 : 1.099 * pow(v, 0.45) - 0.099
    }
}
