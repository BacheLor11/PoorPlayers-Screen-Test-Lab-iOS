//
//  ResolvePatternShaders.metal
//  LivePhotoLab
//
//  「画面信号接收器」图案着色器。
//  用一个覆盖整个裁剪空间的大三角形，在 fragment 阶段按归一化坐标
//  区分「全屏背景层」与「窗口色块层」，因此不需要顶点缓冲。
//  搭配 rgba16Float 像素格式与 EDR，可输出大于 1.0 的扩展亮度。
//

#include <metal_stdlib>
using namespace metal;

struct ResolveUniforms {
    float3 background;   // 背景层颜色（可为 EDR 扩展值）
    float3 foreground;   // 窗口色块颜色（可为 EDR 扩展值）
    float2 position;     // 窗口左上角归一化坐标 (x, y)，以屏幕左上为原点
    float2 size;         // 窗口归一化尺寸 (cx, cy)
};

struct ResolveVertexOut {
    float4 position [[position]];
    float2 uv;
};

/// 覆盖整个裁剪空间的大三角形
vertex ResolveVertexOut resolvePatternVertex(uint vertexID [[vertex_id]]) {
    float2 clip[3] = { float2(-1.0, -1.0), float2(3.0, -1.0), float2(-1.0, 3.0) };
    float2 p = clip[vertexID];
    ResolveVertexOut out;
    out.position = float4(p, 0.0, 1.0);
    // Metal 的裁剪空间 y 轴向上，这里翻转 y，使 uv 原点落在屏幕左上
    out.uv = float2((p.x + 1.0) * 0.5, 1.0 - (p.y + 1.0) * 0.5);
    return out;
}

fragment float4 resolvePatternFragment(ResolveVertexOut in [[stage_in]],
                                       constant ResolveUniforms &uniforms [[buffer(0)]]) {
    bool insideX = in.uv.x >= uniforms.position.x && in.uv.x <= uniforms.position.x + uniforms.size.x;
    bool insideY = in.uv.y >= uniforms.position.y && in.uv.y <= uniforms.position.y + uniforms.size.y;
    float3 rgb = (insideX && insideY) ? uniforms.foreground : uniforms.background;
    return float4(rgb, 1.0);
}
