//
//  ResolveSignalCore.swift
//  LivePhotoLab
//
//  「穷玩组屏幕测试工具箱」— 画面信号接收器（Resolve XML 协议）
//  移植自 PoorPlayers 穷玩组「穷玩组屏幕工具箱」安卓版（已获原作者授权）
//  原作者 B 站：https://space.bilibili.com/326251695
//
//  协议要点（由原 APK 逆向所得）：
//  · 传输：TCP，安卓默认监听端口 20002
//  · 分帧：[4 字节大端 UInt32 长度头] + [UTF-8 XML 报文]，长度有效区间 1...10485760
//  · 变体判定：报文含 "<rectangle" → 变体 B（嵌套型），否则 → 变体 A（扁平型）
//  · 无任何回写：原实现全部 dalvik 指令中不存在 write/OutputStream，纯单向接收，无需 ACK
//

import Foundation
import Network
import Combine

// MARK: - 数据模型（对齐安卓 model.RectangleData / model.SignalData）

/// 一个矩形信号，对应安卓 `model.RectangleData`
struct ResolveRectangle: Equatable {
    /// `<color>` 的 RGB，数值范围 0...(2^bits - 1)
    var color: [Int]?
    /// `<colex>` 的 RGB —— 与 `<color>` 等价的兼容写法，某些校色软件会用它
    var colex: [Int]?
    /// 位深，缺省 8
    var bits: Int = 8
    /// 归一化左上角坐标 [x, y]，缺省 [0, 0]
    var position: [Float] = [0, 0]
    /// 归一化尺寸 [cx, cy]，缺省 [1, 1]（即全屏）
    var size: [Float] = [1, 1]

    /// 实际用于显示的颜色：优先 color，缺失时退回 colex
    var effectiveColor: [Int]? { color ?? colex }
}

/// 一帧信号，对应安卓 `model.SignalData`：全屏背景 + 可选窗口色块
struct ResolveSignalFrame: Equatable {
    var background: ResolveRectangle
    var window: ResolveRectangle?
}

extension ResolveRectangle {
    /// 默认背景：纯黑全屏
    static func defaultBackground() -> ResolveRectangle {
        ResolveRectangle(color: [0, 0, 0], colex: nil, bits: 8,
                         position: [0, 0], size: [1, 1])
    }

    /// 位深归一化，等价于安卓 `raw * 255 / ((1 << bits) - 1)` 后再由 UI 除以 255
    static func rgbUnit(_ raw: [Int]?, bits: Int) -> (r: Double, g: Double, b: Double) {
        guard let raw = raw, raw.count >= 3 else { return (0, 0, 0) }
        let divisor = Double(max(1, (1 << max(1, bits)) - 1))
        func unit(_ v: Int) -> Double {
            min(1, max(0, Double(v) / divisor))
        }
        return (unit(raw[0]), unit(raw[1]), unit(raw[2]))
    }
}

// MARK: - XML 解析

/// Resolve XML 解析器（SAX），自动识别变体 A / B
final class ResolveXMLParser: NSObject, XMLParserDelegate {

    private enum Variant { case a, b }

    private var variant: Variant = .b
    // 变体 A：扁平元素，直接分别填这两条
    private var flatBackground = ResolveRectangle.defaultBackground()
    private var flatWindow: ResolveRectangle?
    // 变体 B：<rectangle> 列表
    private var rectangles: [ResolveRectangle] = []
    private var current: ResolveRectangle?
    // <bits> 若以元素文本形式给出，则在此累积
    private var isReadingBits = false
    private var bitsText = ""

    /// 解析一帧 XML 报文，失败返回 nil
    func parse(_ xml: String) -> ResolveSignalFrame? {
        variant = xml.contains("<rectangle") ? .b : .a
        flatBackground = ResolveRectangle.defaultBackground()
        flatWindow = nil
        rectangles = []
        current = nil
        isReadingBits = false
        bitsText = ""

        let parser = XMLParser(data: Data(xml.utf8))
        parser.delegate = self
        guard parser.parse() else { return nil }

        switch variant {
        case .b:
            // 第 1 个 rectangle 作背景、第 2 个作窗口；只有 1 个时视为窗口，背景补默认黑
            if rectangles.count >= 2 {
                return ResolveSignalFrame(background: rectangles[0], window: rectangles[1])
            } else if rectangles.count == 1 {
                return ResolveSignalFrame(background: .defaultBackground(), window: rectangles[0])
            }
            return nil
        case .a:
            return ResolveSignalFrame(background: flatBackground, window: flatWindow)
        }
    }

    // MARK: XMLParserDelegate

    func parser(_ parser: XMLParser,
                didStartElement elementName: String,
                namespaceURI: String?,
                qualifiedName qName: String?,
                attributes attributeDict: [String: String] = [:]) {
        let element = elementName.lowercased()

        switch element {
        case "bits":
            isReadingBits = true
            bitsText = ""
            if let v = intAttribute(attributeDict, keys: ["value", "bits"]) {
                applyBits(v)
            }

        case "geometry":
            var x: Float?, y: Float?, cx: Float?, cy: Float?
            if let s = attributeDict["x"] { x = Float(s) }
            if let s = attributeDict["y"] { y = Float(s) }
            if let s = attributeDict["cx"] { cx = Float(s) }
            if let s = attributeDict["cy"] { cy = Float(s) }
            applyGeometry(x: x ?? 0, y: y ?? 0, cx: cx ?? 1, cy: cy ?? 1)

        case "color", "colex":
            guard let rgb = rgbAttributes(attributeDict) else { return }
            if element == "color" {
                setColor(rgb)
            } else {
                setColex(rgb)
            }

        case "background":
            guard let rgb = rgbAttributes(attributeDict) else { return }
            if variant == .b {
                current?.color = rgb
            } else {
                flatBackground.color = rgb
            }

        case "rectangle":
            current = ResolveRectangle()

        default:
            break
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) {
        guard isReadingBits else { return }
        bitsText += string.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func parser(_ parser: XMLParser,
                didEndElement elementName: String,
                namespaceURI: String?,
                qualifiedName qName: String?) {
        let element = elementName.lowercased()

        switch element {
        case "bits":
            if isReadingBits, let v = Int(bitsText) { applyBits(v) }
            isReadingBits = false
            bitsText = ""
        case "rectangle":
            if let r = current { rectangles.append(r) }
            current = nil
        default:
            break
        }
    }

    // MARK: 取值辅助

    /// 读取 RGB 属性：同时接受 red/green/blue 与 r/g/b 两种写法
    private func rgbAttributes(_ attrs: [String: String]) -> [Int]? {
        let lower = Dictionary(uniqueKeysWithValues: attrs.map { ($0.key.lowercased(), $0.value) })
        func value(_ keys: [String]) -> Int? {
            for k in keys {
                if let s = lower[k], let v = Int(s) { return v }
            }
            return nil
        }
        guard let r = value(["red", "r"]),
              let g = value(["green", "g"]),
              let b = value(["blue", "b"]) else { return nil }
        return [r, g, b]
    }

    private func intAttribute(_ attrs: [String: String], keys: [String]) -> Int? {
        let lower = Dictionary(uniqueKeysWithValues: attrs.map { ($0.key.lowercased(), $0.value) })
        for k in keys {
            if let s = lower[k], let v = Int(s) { return v }
        }
        return nil
    }

    private func applyBits(_ value: Int) {
        let bits = max(1, value)
        if variant == .b {
            current?.bits = bits
        } else {
            flatBackground.bits = bits
            flatWindow?.bits = bits
            pendingBits = bits
        }
    }

    /// 变体 A 下 bits 可能先于 <color> 出现，这里暂存以便后续补给窗口
    private var pendingBits: Int = 8

    private func ensureFlatWindow() -> ResolveRectangle {
        if flatWindow == nil {
            flatWindow = ResolveRectangle()
            flatWindow?.bits = pendingBits
        }
        return flatWindow!
    }

    private func setColor(_ rgb: [Int]) {
        if variant == .b {
            current?.color = rgb
        } else {
            _ = ensureFlatWindow()
            flatWindow?.color = rgb
        }
    }

    private func setColex(_ rgb: [Int]) {
        if variant == .b {
            current?.colex = rgb
        } else {
            _ = ensureFlatWindow()
            flatWindow?.colex = rgb
        }
    }

    private func applyGeometry(x: Float, y: Float, cx: Float, cy: Float) {
        if variant == .b {
            current?.position = [x, y]
            current?.size = [cx, cy]
        } else {
            _ = ensureFlatWindow()
            flatWindow?.position = [x, y]
            flatWindow?.size = [cx, cy]
        }
    }
}

// MARK: - 接收日志

/// 一条收到的原始报文（用于排障与向原作者核对协议）
struct ResolveSignalLogEntry: Identifiable, Equatable {
    let id = UUID()
    let date: Date
    let rawXML: String
    let variant: String
    let summary: String
}

// MARK: - TCP 收发服务

/// 画面信号接收服务：支持接收端（监听）与发送端（主动连接）两种模式
final class ResolveSignalService: NSObject, ObservableObject {

    enum Mode: String, CaseIterable, Identifiable {
        case server = "接收端（监听）"
        case client = "发送端（连接）"
        var id: String { rawValue }
    }

    enum ConnState: Equatable {
        case idle
        case listening(UInt16)
        case connecting
        case connected(String)
        case failed(String)

        var isActive: Bool {
            switch self {
            case .listening, .connecting, .connected: return true
            case .idle, .failed: return false
            }
        }
    }

    @Published private(set) var state: ConnState = .idle
    @Published private(set) var frame: ResolveSignalFrame?
    @Published private(set) var logs: [ResolveSignalLogEntry] = []
    @Published private(set) var receivedCount: Int = 0

    /// 观测到的端口（监听成功后回填真实端口）
    @Published private(set) var boundPort: UInt16 = 0

    private var listener: NWListener?
    private var connection: NWConnection?
    private var recvBuffer = Data()
    private let parser = ResolveXMLParser()

    // MARK: 接收端

    func startServer(port: UInt16) {
        stop()
        let parameters = NWParameters.tcp
        parameters.allowLocalEndpointReuse = true
        do {
            let listener = try NWListener(using: parameters, on: NWEndpoint.Port(rawValue: port)!)
            self.listener = listener
            listener.stateUpdateHandler = { [weak self] state in
                DispatchQueue.main.async {
                    guard let self else { return }
                    switch state {
                    case .ready:
                        let actual = UInt16(listener.port?.rawValue ?? port)
                        self.boundPort = actual
                        self.state = .listening(actual)
                    case .failed(let error):
                        self.state = .failed(error.localizedDescription)
                    case .cancelled:
                        self.state = .idle
                    default:
                        break
                    }
                }
            }
            listener.newConnectionHandler = { [weak self] connection in
                DispatchQueue.main.async { self?.attach(connection) }
            }
            listener.start(queue: .main)
        } catch {
            state = .failed(error.localizedDescription)
        }
    }

    // MARK: 发送端

    func connect(host: String, port: UInt16) {
        stop()
        state = .connecting
        let endpoint = NWEndpoint.hostPort(host: NWEndpoint.Host(host), port: NWEndpoint.Port(rawValue: port)!)
        let connection = NWConnection(to: endpoint, using: .tcp)
        attach(connection)   // attach 内部统一负责 start，两条连接路径行为一致
    }

    func stop() {
        listener?.cancel()
        listener = nil
        connection?.cancel()
        connection = nil
        recvBuffer.removeAll(keepingCapacity: true)
        state = .idle
    }

    // MARK: 连接数据通路

    private func attach(_ connection: NWConnection) {
        // 同一时刻只保留一条数据连接：接入新连接前先关掉旧的（监听本身继续保留）
        if let previous = self.connection { previous.cancel() }
        self.connection = connection
        recvBuffer.removeAll(keepingCapacity: true)
        connection.stateUpdateHandler = { [weak self] state in
            DispatchQueue.main.async {
                guard let self else { return }
                switch state {
                case .ready:
                    if case .listening(let port) = self.state {
                        self.state = .connected("已连接 · 端口 \(port)")
                    } else {
                        self.state = .connected("已连接")
                    }
                    self.receiveLoop()
                case .failed(let error):
                    if case .listening = self.state {
                        // 监听模式下单个连接失败不应中断监听
                    } else {
                        self.state = .failed(error.localizedDescription)
                    }
                case .cancelled:
                    if case .listening = self.state {
                        // 保持监听
                    } else {
                        self.state = .idle
                    }
                default:
                    break
                }
            }
        }
        // 关键：NWListener 通过 newConnectionHandler 交付的连接处于挂起态，
        // 必须自己调用 start(queue:) 才会推进到 .ready 并开始收发数据。
        // （此前 Server 模式漏了这一步 → 对端卡在 connecting、本端一直停在 listening）
        connection.start(queue: .main)
        if case .listening = state {
            receiveLoop()
        }
    }

    private func receiveLoop() {
        connection?.receive(minimumIncompleteLength: 1, maximumLength: 1 << 20) { [weak self] data, _, isComplete, error in
            guard let self else { return }
            DispatchQueue.main.async {
                if let data, !data.isEmpty {
                    self.recvBuffer.append(data)
                    self.drainBuffer()
                }
                if isComplete || error != nil {
                    if case .listening = self.state {
                        // 客户端断开，继续监听即可
                    } else {
                        self.state = error.map { .failed($0.localizedDescription) } ?? .idle
                    }
                    return
                }
                self.receiveLoop()
            }
        }
    }

    /// 按「4 字节大端长度头 + XML 体」拆帧（与原实现一致的长度校验）
    private func drainBuffer() {
        while recvBuffer.count >= 4 {
            let bytes = [UInt8](recvBuffer.prefix(4))
            let length = Int(bytes[0]) << 24 | Int(bytes[1]) << 16 | Int(bytes[2]) << 8 | Int(bytes[3])
            if length <= 0 || length > 10_485_760 {
                recvBuffer.removeAll(keepingCapacity: true)
                return
            }
            guard recvBuffer.count >= 4 + length else { return }   // 等待后续数据补齐
            // 必须用「相对切片」而非绝对下标 4：Data 在 removeFirst() 之后 startIndex
            // 不会归零而是保留偏移，用绝对下标取第二帧及之后的报文会越界 trap
            // （表现为收到第二条指令就闪退）。dropFirst / prefix 恒成立、不会越界。
            let xml = String(decoding: recvBuffer.dropFirst(4).prefix(length), as: UTF8.self)
            recvBuffer.removeFirst(4 + length)
            handle(xml: xml)
        }
    }

    private func handle(xml: String) {
        receivedCount += 1
        let variant = xml.contains("<rectangle") ? "B" : "A"
        let parsed = parser.parse(xml)
        let summary: String
        if let parsed {
            let (br, bg, bb) = ResolveRectangle.rgbUnit(parsed.background.effectiveColor, bits: parsed.background.bits)
            if let window = parsed.window {
                let (wr, wg, wb) = ResolveRectangle.rgbUnit(window.effectiveColor, bits: window.bits)
                summary = String(format: "背景 %.3f/%.3f/%.3f · 窗口 %.3f/%.3f/%.3f @ %.2f,%.2f %.2fx%.2f bits=%d",
                                 br, bg, bb, wr, wg, wb,
                                 window.position[0], window.position[1],
                                 window.size[0], window.size[1], window.bits)
            } else {
                summary = String(format: "背景 %.3f/%.3f/%.3f（无窗口）", br, bg, bb)
            }
        } else {
            summary = "解析失败"
        }
        if parsed != nil { frame = parsed }
        let entry = ResolveSignalLogEntry(date: Date(), rawXML: xml, variant: variant, summary: summary)
        logs.insert(entry, at: 0)
        if logs.count > 60 { logs.removeLast(logs.count - 60) }
    }

    func clearLogs() {
        logs.removeAll()
        receivedCount = 0
        frame = nil
    }
}

// MARK: - 本机 IP

enum ResolveNetworkUtils {
    /// 取本机局域网 IPv4 地址
    static func localIPv4() -> String? {
        var address: String?
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddr) == 0, let first = ifaddr else { return nil }
        defer { freeifaddrs(ifaddr) }

        for pointer in sequence(first: first, next: { $0.pointee.ifa_next }) {
            let interface = pointer.pointee
            let addrFamily = interface.ifa_addr.pointee.sa_family
            if addrFamily == UInt8(AF_INET) {
                let name = String(cString: interface.ifa_name)
                if name == "en0" || name == "en1" || name.hasPrefix("en") {
                    var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                    getnameinfo(interface.ifa_addr,
                                socklen_t(interface.ifa_addr.pointee.sa_len),
                                &hostname, socklen_t(hostname.count),
                                nil, socklen_t(0), NI_NUMERICHOST)
                    let candidate = String(cString: hostname)
                    if !candidate.isEmpty, !candidate.hasPrefix("127.") {
                        address = candidate
                    }
                }
            }
        }
        return address
    }
}
