//
//  PoorPlayersScreenTestLabApp.swift
//  PoorPlayersScreenTestLab
//
//  「屏幕测试工具箱」独立 App（v1.0.0 起）
//
//  从「A宝的工具箱」中把穷玩组屏幕测试工具箱（已获原作者授权）单独抽出成独立 App，
//  以便声明 UIRequiresFullScreen=true：iPad 上全屏测试时状态栏可完整隐藏
//  （多任务 App 被系统禁止隐藏状态栏）。
//

import SwiftUI

@main
struct PoorPlayersScreenTestLabApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
