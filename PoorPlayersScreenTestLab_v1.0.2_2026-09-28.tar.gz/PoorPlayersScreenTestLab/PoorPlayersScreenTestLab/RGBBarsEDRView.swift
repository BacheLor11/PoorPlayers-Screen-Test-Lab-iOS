//
//  RGBBarsEDRView.swift
//  LivePhotoLab
//
//  「RGB 测试 · HDR Photo-RGB GainMap」模式的 EDR 渲染层（v2.19.36）。
//
//  原版（RgbTestViewModel.generateRgbGainmapBitmap 反编译对照）：
//    主图 = sRGB 色彩空间的 RGB 三色横条（上红/中绿/下蓝，各 1/3 高）；
//    增益图 = 左半白 (255,255,255)、右半 (0,85,170) 的彩色增益图；
//    Gainmap 参数：ratioMin = 1.0、ratioMax = 4.0、gamma = 1.0、
//    minDisplayRatioForHdrTransition = 1.0、displayRatioForFullHdr = 4.0。
//  语义（原版界面标签「左4X 右1X/2X/3X」）：
//    左半 R/G/B 全部 4 倍亮度；右半 R 1×（增益 0）、G 2×（85/255）、B 3×（170/255）。
//
//  iOS 移植：不生成真的 gain map 位图再交给系统（屏幕显示路径拿不到 Android
//  Gainmap 那种自动合成），改为等价直出——extendedLinearSRGB 的 EDR Metal 层，
//  fragment 按 uv 所在条带 × 左右增益直接输出 >1.0 的线性值，效果与原版一致；
//  导出侧则真的写 Gain Map（复用 HDRGainMapExporter，ratioMax=4）。
//

import SwiftUI
import Metal
import MetalKit
import QuartzCore

// MARK: - Uniforms（布局须与下方 shader 一致：SIMD3 stride 16 + 2×Float = 48 字节）

struct RGBBarsUniforms {
    var gainL: SIMD3<Float>
    var gainR: SIMD3<Float>
    var split: Float
    var pad: Float = 0
}

// MARK: - Metal 源码（独立于 ResolvePatternShaders，避免影响信号接收器管线）

private let rgbBarsShaderSource = """
#include <metal_stdlib>
using namespace metal;

struct RgbBarsUniforms {
    float3 gainL;   // 左半增益（线性乘数，可 >1.0）
    float3 gainR;   // 右半增益
    float split;    // 左右分界的 uv.x（0.5）
    float pad;
};

struct RgbVertexOut {
    float4 position [[position]];
    float2 uv;
};

vertex RgbVertexOut rgbBarsVertex(uint vid [[vertex_id]]) {
    float2 clip[3] = { float2(-1.0, -1.0), float2(3.0, -1.0), float2(-1.0, 3.0) };
    float2 p = clip[vid];
    RgbVertexOut o;
    o.position = float4(p, 0.0, 1.0);
    o.uv = float2((p.x + 1.0) * 0.5, 1.0 - (p.y + 1.0) * 0.5);
    return o;
}

fragment float4 rgbBarsFragment(RgbVertexOut in [[stage_in]],
                                constant RgbBarsUniforms &u [[buffer(0)]]) {
    // RGB 三色横条：上 1/3 红、中 1/3 绿、下 1/3 蓝（线性值 1.0 = SDR 满亮度）
    float3 base = in.uv.y < (1.0 / 3.0) ? float3(1.0, 0.0, 0.0)
                : in.uv.y < (2.0 / 3.0) ? float3(0.0, 1.0, 0.0)
                                        : float3(0.0, 0.0, 1.0);
    float3 gain = in.uv.x < u.split ? u.gainL : u.gainR;
    return float4(base * gain, 1.0);
}
"""

// MARK: - SwiftUI 桥接

struct RGBBarsEDRView: UIViewRepresentable {

    /// 左半增益（原版 4,4,4）
    var gainL: SIMD3<Float>
    /// 右半增益（原版 1,2,3）
    var gainR: SIMD3<Float>

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> MTKView {
        let view = MTKView(frame: .zero)
        view.device = MTLCreateSystemDefaultDevice()
        view.delegate = context.coordinator
        view.isPaused = true
        view.enableSetNeedsDisplay = true
        // rgba16Float 承载 >1.0 的 EDR 扩展值
        view.colorPixelFormat = .rgba16Float
        view.clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 1)
        context.coordinator.prepare(view)
        return view
    }

    func updateUIView(_ view: MTKView, context: Context) {
        context.coordinator.uniforms = RGBBarsUniforms(gainL: gainL, gainR: gainR, split: 0.5)
        context.coordinator.applyEDR(to: view)
        view.setNeedsDisplay()
    }

    // MARK: Coordinator

    final class Coordinator: NSObject, MTKViewDelegate {

        var uniforms = RGBBarsUniforms(gainL: SIMD3<Float>(repeating: 4),
                                       gainR: SIMD3<Float>(1, 2, 3),
                                       split: 0.5)
        private var pipeline: MTLRenderPipelineState?
        private var commandQueue: MTLCommandQueue?
        private var edrApplied = false

        func prepare(_ view: MTKView) {
            guard let device = view.device else { return }
            commandQueue = device.makeCommandQueue()
            // 内嵌源码编译（不依赖 .metal 文件，独立于信号接收器的 default library）
            do {
                let library = try device.makeLibrary(source: rgbBarsShaderSource, options: nil)
                let descriptor = MTLRenderPipelineDescriptor()
                descriptor.vertexFunction = library.makeFunction(name: "rgbBarsVertex")
                descriptor.fragmentFunction = library.makeFunction(name: "rgbBarsFragment")
                descriptor.colorAttachments[0].pixelFormat = view.colorPixelFormat
                pipeline = try device.makeRenderPipelineState(descriptor: descriptor)
            } catch {
                NSLog("[RGBBars] shader init failed: \(error)")
            }
        }

        /// EDR 层配置（与「画面信号接收器」EDR 分支一致）：extendedLinearSRGB + EDR
        func applyEDR(to view: MTKView) {
            guard !edrApplied, let metalLayer = view.layer as? CAMetalLayer else { return }
            metalLayer.colorspace = CGColorSpace(name: CGColorSpace.extendedLinearSRGB)
            metalLayer.wantsExtendedDynamicRangeContent = true
            metalLayer.edrMetadata = nil
            edrApplied = true
        }

        func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}

        func draw(in view: MTKView) {
            guard let descriptor = view.currentRenderPassDescriptor,
                  let pipeline,
                  let queue = commandQueue,
                  let buffer = queue.makeCommandBuffer(),
                  let encoder = buffer.makeRenderCommandEncoder(descriptor: descriptor) else { return }
            var uniforms = self.uniforms
            encoder.setRenderPipelineState(pipeline)
            encoder.setVertexBytes(&uniforms, length: MemoryLayout<RGBBarsUniforms>.stride, index: 0)
            encoder.setFragmentBytes(&uniforms, length: MemoryLayout<RGBBarsUniforms>.stride, index: 0)
            encoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
            encoder.endEncoding()
            if let drawable = view.currentDrawable { buffer.present(drawable) }
            buffer.commit()
        }
    }
}
