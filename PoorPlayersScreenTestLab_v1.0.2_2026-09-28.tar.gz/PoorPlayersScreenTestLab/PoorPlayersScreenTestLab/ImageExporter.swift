import Foundation
import ImageIO
import Photos
import UIKit
import CoreLocation

/// 统一图片导出器（Beta）
///
/// 把各个图片工具零散的"保存 / 导出"逻辑下沉为一套可复用能力：
/// 1. 栅格导出（JPEG / HEIC，带 EXIF / GPS / TIFF）
/// 2. 朝向归一化（从根本上避免"竖屏转 90°"类问题——各工具无需各自处理 Orientation）
/// 3. 从源数据重编码（保留 HDR 增益图 / 深度图，并可改写元数据，像素零重编码）
/// 4. 实况照片（Live Photo）保存（主图 + 配对视频）
///
/// 本模块为研究性 Beta，**不改变任何现有工具的实现**，仅作为统一能力的试验田。
/// 现有最全参考实现位于 PhotoInfoEditorView（HDR / Live Photo / 深度图均经真机验证）。
enum ImageExporter {

    // MARK: - 错误
    enum ExporterError: Error, LocalizedError {
        case cannotCreateDestination
        case cannotDecode
        case encodeFailed
        case noPhotoLibraryAuth
        case cannotWriteTempFile

        var errorDescription: String? {
            switch self {
            case .cannotCreateDestination: return "无法创建图像编码器"
            case .cannotDecode:           return "无法解码图像"
            case .encodeFailed:           return "图像编码失败"
            case .noPhotoLibraryAuth:     return "未授权相册，无法保存"
            case .cannotWriteTempFile:    return "无法写入临时文件"
            }
        }
    }

    // MARK: - 元数据
    /// 统一元数据容器。调用方只填业务字段；朝向由模块统一处理，无需手动写 Orientation。
    struct Metadata {
        var exif: [CFString: Any] = [:]
        var tiff: [CFString: Any] = [:]
        var gps: [CFString: Any]?
        /// 可选：源图朝向（仅"从源重编码"时用于保留方向，避免旋转）。栅格直出无需设置。
        var orientation: CGImagePropertyOrientation?

        static var empty: Metadata { Metadata() }
    }

    // MARK: - 输出格式
    enum Format {
        case jpeg(quality: Double = 0.92)
        case heic
    }

    // MARK: - 1. 栅格导出（已归一化位图）
    /// 把已渲染 / 已正立的位图按格式 + 元数据写入相册。
    /// 位图须已正立（建议用 `save(from:)` 让模块统一归一化），元数据不要带 Orientation。
    @discardableResult
    static func save(_ cg: CGImage, format: Format, metadata: Metadata = .empty,
                     location: CLLocation? = nil,
                     suggestedFileName: String = "导出图片") async -> Result<Void, Error> {
        guard let data = encode(cg, format: format, metadata: metadata) else {
            return .failure(ExporterError.encodeFailed)
        }
        return await saveData(data, location: location, suggestedFileName: suggestedFileName)
    }

    /// 编码为文件数据（不写相册），便于上层自行分享 / 二次处理。
    static func encode(_ cg: CGImage, format: Format, metadata: Metadata = .empty) -> Data? {
        let uti: CFString
        let quality: Double
        switch format {
        case .jpeg(let q): uti = "public.jpeg" as CFString; quality = q
        case .heic:        uti = "public.heic" as CFString;  quality = 1.0
        }
        let out = NSMutableData()
        guard let dest = CGImageDestinationCreateWithData(out, uti, 1, nil) else { return nil }
        var props: [CFString: Any] = [kCGImageDestinationLossyCompressionQuality: quality]
        if !metadata.exif.isEmpty { props[kCGImagePropertyExifDictionary] = metadata.exif }
        if !metadata.tiff.isEmpty { props[kCGImagePropertyTIFFDictionary] = metadata.tiff }
        if let g = metadata.gps { props[kCGImagePropertyGPSDictionary] = g }
        // 注意：栅格直出不写 Orientation——位图已由调用方归一化为正立
        CGImageDestinationAddImage(dest, cg, props as CFDictionary)
        guard CGImageDestinationFinalize(dest) else { return nil }
        return out as Data
    }

    // MARK: - 2. 从 UIImage 导出（统一朝向归一化）
    /// 入口级便利方法：UIImage（可能带朝向）→ 归一化为正立位图 → 按格式 + 元数据导出。
    /// 从根本上避免各工具"竖屏转 90°"类 bug——朝向由这里统一处理。
    @discardableResult
    static func save(from image: UIImage, format: Format = .jpeg(), metadata: Metadata = .empty,
                     location: CLLocation? = nil,
                     suggestedFileName: String = "导出图片") async -> Result<Void, Error> {
        guard let cg = Self.uprightCGImage(from: image) else {
            return .failure(ExporterError.cannotDecode)
        }
        return await save(cg, format: format, metadata: metadata,
                          location: location, suggestedFileName: suggestedFileName)
    }

    /// UIImage 朝向归一化：已正立直接用 cgImage；否则用图形上下文按 imageOrientation 渲染为正立位图。
    private static func uprightCGImage(from image: UIImage) -> CGImage? {
        if image.imageOrientation == .up, let cg = image.cgImage { return cg }
        let size = image.size
        UIGraphicsBeginImageContextWithOptions(size, false, image.scale)
        defer { UIGraphicsEndImageContext() }
        image.draw(in: CGRect(origin: .zero, size: size))
        return UIGraphicsGetImageFromCurrentImageContext()?.cgImage
    }

    // MARK: - 3. 从源数据重编码（保留 HDR 增益图 / 深度图，改写元数据）
    /// 适用于"改元数据但不想动像素 / 不想丢 HDR·Live·深度"的场景（EXIF 编辑器核心逻辑）。
    /// 采用 CGImageDestinationAddImageFromSource 的合并语义：只覆盖要改的键，其余沿源流保留
    /// （含 HEIF 顶层字典里的 HDR 增益图引用、Live Photo 配对标识、方向等）。
    static func encodeFromSource(_ srcData: Data, metadata: Metadata = .empty,
                                 preserveGainMap: Bool = true,
                                 preserveDepth: Bool = true) -> Data? {
        guard let src = CGImageSourceCreateWithData(srcData as CFData, nil),
              let props = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any] else { return nil }
        let uti = CGImageSourceGetType(src) ?? "public.jpeg" as CFString
        let out = NSMutableData()
        guard let dest = CGImageDestinationCreateWithData(out, uti, 1, nil) else { return nil }

        let isHEIF = (uti as String) == "public.heic" || (uti as String) == "public.heif"
        let hasGainMap = isHEIF
            && CGImageSourceCopyAuxiliaryDataInfoAtIndex(src, 0, kCGImageAuxiliaryDataTypeHDRGainMap) != nil

        var newProps: [CFString: Any] = props
        if preserveGainMap && hasGainMap {
            // 让编码器自己保留并正确关联增益图（随主图缩放同步），
            // 替代手动塞回（易与主图失联导致 HDR 丢失）。
            newProps[kCGImageDestinationPreserveGainMap] = kCFBooleanTrue
        }
        if preserveDepth {
            // 保留原图 MakerApple 字典（含 Live Photo 资产标识 "17"），
            // 保证重新编码后的照片仍能与原始配对视频成功组合为实况照片（避免 3302）。
            if let maker = props[kCGImagePropertyMakerAppleDictionary] as? [String: Any] {
                newProps[kCGImagePropertyMakerAppleDictionary] = maker
            }
        }
        if !metadata.exif.isEmpty { newProps[kCGImagePropertyExifDictionary] = metadata.exif }
        if !metadata.tiff.isEmpty { newProps[kCGImagePropertyTIFFDictionary] = metadata.tiff }
        if let g = metadata.gps { newProps[kCGImagePropertyGPSDictionary] = g }
        else { newProps.removeValue(forKey: kCGImagePropertyGPSDictionary) }
        if let o = metadata.orientation { newProps[kCGImagePropertyOrientation] = o }

        CGImageDestinationAddImageFromSource(dest, src, 0, newProps as CFDictionary)

        // 深度图 / 视差图：AddImageFromSource 默认只保留 GainMap，深度会丢；
        // 用标准 API 手动拷回（须在 AddImageFromSource 之后、Finalize 之前调用）。
        if preserveDepth {
            for auxType in [kCGImageAuxiliaryDataTypeDisparity, kCGImageAuxiliaryDataTypeDepth] {
                if let aux = CGImageSourceCopyAuxiliaryDataInfoAtIndex(src, 0, auxType) {
                    CGImageDestinationAddAuxiliaryDataInfo(dest, auxType, aux)
                }
            }
        }

        guard CGImageDestinationFinalize(dest) else { return nil }
        return out as Data
    }

    // MARK: - 4. 实况照片（Live Photo）保存
    /// 主图数据 + 配对视频（本地 URL）。视频缺失则降级为静态图保存（不报错中断）。
    @discardableResult
    static func saveLivePhoto(photoData: Data, videoURL: URL?,
                              metadata: Metadata = .empty,
                              location: CLLocation? = nil,
                              suggestedFileName: String = "实况照片") async -> Result<Void, Error> {
        if ProcessInfo.processInfo.isiOSAppOnMac {
            // Mac：无相册、也无 Live Photo 容器，改为把主图（+ 配对视频）一起导出到指定目录
            var items: [(data: Data, fileName: String)] =
                [(photoData, "\(suggestedFileName).\(photoData.imageExtension())")]
            if let videoURL, let vData = try? Data(contentsOf: videoURL) {
                items.append((vData, "\(suggestedFileName).mov"))
            }
            switch await MacFileSaver.save(items) {
            case .success:            return .success(())
            case .failure(let error): return .failure(error)
            }
        }
        let photoURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension(photoData.imageExtension())
        do { try photoData.write(to: photoURL, options: .atomic) }
        catch { return .failure(ExporterError.cannotWriteTempFile) }

        var realVideoURL: URL?
        if let videoURL {
            let vURL = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString)
                .appendingPathExtension("mov")
            if (try? FileManager.default.copyItem(at: videoURL, to: vURL)) != nil { realVideoURL = vURL }
        }
        defer {
            try? FileManager.default.removeItem(at: photoURL)
            if let realVideoURL { try? FileManager.default.removeItem(at: realVideoURL) }
        }

        guard await PHPhotoLibrary.requestAuthAsync() else { return .failure(ExporterError.noPhotoLibraryAuth) }
        return await withCheckedContinuation { cont in
            PHPhotoLibrary.shared().performChanges({
                let creation = PHAssetCreationRequest.forAsset()
                let photoOptions = PHAssetResourceCreationOptions()
                creation.addResource(with: .photo, fileURL: photoURL, options: photoOptions)
                if let realVideoURL {
                    let vOptions = PHAssetResourceCreationOptions()
                    vOptions.shouldMoveFile = false
                    creation.addResource(with: .pairedVideo, fileURL: realVideoURL, options: vOptions)
                }
                if let loc = location { creation.location = loc }
            }) { ok, err in
                cont.resume(returning: ok ? .success(()) : .failure(err ?? ExporterError.encodeFailed))
            }
        }
    }

    // MARK: - 0. 取相册资产原始数据（零转码，保留 HDR 增益图 / 深度图 / Live 配对）
    /// 通过 assetIdentifier 从相册取回该照片的**原始字节**（不走 itemProvider 转码，避免增益图 / 深度被剥离），
    /// 同时取回 Live Photo 的配对视频（如有）。用于"保留元数据导出"等需 100% 保真的场景。
    /// - Returns: (photoData: 原始照片数据, videoURL: 原始配对视频临时路径；非 Live 时为 nil)
    static func fetchOriginalAsset(assetID: String) async -> (photoData: Data?, videoURL: URL?) {
        guard let asset = PHAsset.fetchAssets(withLocalIdentifiers: [assetID], options: nil).firstObject else {
            return (nil, nil)
        }
        let resources = PHAssetResource.assetResources(for: asset)

        // 配对视频（Live Photo）
        var videoURL: URL?
        if let vid = resources.first(where: { $0.type == .pairedVideo }) {
            let url = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString)
                .appendingPathExtension("mov")
            await withCheckedContinuation { cont in
                PHAssetResourceManager.default().writeData(for: vid, toFile: url, options: nil) { _ in
                    cont.resume(returning: ())
                }
            }
            if (try? Data(contentsOf: url)) != nil { videoURL = url }
        }

        // 原始照片字节（优先 fullSizePhoto，退回 photo）
        let photoRes = resources.first(where: { $0.type == .fullSizePhoto })
            ?? resources.first(where: { $0.type == .photo })
        guard let pr = photoRes else { return (nil, videoURL) }
        let purl = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("heic")
        await withCheckedContinuation { cont in
            PHAssetResourceManager.default().writeData(for: pr, toFile: purl, options: nil) { _ in
                cont.resume(returning: ())
            }
        }
        let data = try? Data(contentsOf: purl)
        return (data, videoURL)
    }

    // MARK: - 5. 数据直写相册
    @discardableResult
    static func saveData(_ data: Data, location: CLLocation? = nil,
                         suggestedFileName: String = "导出图片") async -> Result<Void, Error> {
        if ProcessInfo.processInfo.isiOSAppOnMac {
            // Mac：无相册，改为弹访达「存储」对话框存到用户指定路径
            let ext = data.imageExtension()
            let name = suggestedFileName.hasSuffix(".\(ext)")
                ? suggestedFileName : "\(suggestedFileName).\(ext)"
            switch await MacFileSaver.save([(data: data, fileName: name)]) {
            case .success:            return .success(())
            case .failure(let error): return .failure(error)
            }
        }
        guard await PHPhotoLibrary.requestAuthAsync() else { return .failure(ExporterError.noPhotoLibraryAuth) }
        return await withCheckedContinuation { cont in
            PHPhotoLibrary.shared().performChanges({
                let req = PHAssetCreationRequest.forAsset()
                req.addResource(with: .photo, data: data, options: nil)
                if let loc = location { req.location = loc }
            }) { ok, err in
                cont.resume(returning: ok ? .success(()) : .failure(err ?? ExporterError.encodeFailed))
            }
        }
    }
}

// MARK: - 辅助
extension Data {
    /// 由图像数据推断文件扩展名（写临时文件用）
    fileprivate func imageExtension() -> String {
        guard let s = CGImageSourceCreateWithData(self as CFData, nil),
              let uti = CGImageSourceGetType(s) as String? else { return "jpg" }
        let l = uti.lowercased()
        if l.contains("jpeg") { return "jpg" }
        if l.contains("heic") || l.contains("heif") { return "heic" }
        return "jpg"
    }
}

extension PHPhotoLibrary {
    /// 异步请求"添加照片"授权
    fileprivate static func requestAuthAsync() async -> Bool {
        await withCheckedContinuation { cont in
            PHPhotoLibrary.requestAuthorization(for: .addOnly) { st in
                cont.resume(returning: st == .authorized || st == .limited)
            }
        }
    }
}

// MARK: - Mac 文件保存（弹访达「存储」对话框）

/// Mac 上替代「写入相册」的保存通道：弹出系统访达保存面板，存到用户指定路径。
///
/// 「Designed for iPad」跑在 Mac 上时编译产物仍是 iOS 二进制、AppKit 不可用，
/// 因此用纯 UIKit 的 `UIDocumentPickerViewController(forExporting:asCopy:)`——
/// 它在 Mac 上即系统访达的「存储」对话框。
enum MacFileSaver {

    enum SaveError: Error, LocalizedError {
        case emptyItems
        case cannotWriteTempFile
        case noPresenter

        var errorDescription: String? {
            switch self {
            case .emptyItems:          return "没有可保存的内容"
            case .cannotWriteTempFile: return "无法写入临时文件"
            case .noPresenter:         return "找不到可用于弹出保存面板的窗口"
            }
        }
    }

    struct Cancelled: Error, LocalizedError {
        var errorDescription: String? { "已取消保存" }
    }

    /// 把若干份数据一次导出到用户指定目录（只弹一次访达）。
    /// - Parameter items: （数据, 建议文件名，**需带扩展名**）
    /// - Returns: 用户选择的保存位置
    @MainActor
    static func save(_ items: [(data: Data, fileName: String)]) async -> Result<[URL], Error> {
        guard !items.isEmpty else { return .failure(SaveError.emptyItems) }

        // 导出面板收 URL 而非 Data → 先落临时文件，结束后清理
        var tempURLs: [URL] = []
        for item in items {
            let url = FileManager.default.temporaryDirectory.appendingPathComponent(item.fileName)
            try? FileManager.default.removeItem(at: url)
            do { try item.data.write(to: url) }
            catch { return .failure(SaveError.cannotWriteTempFile) }
            tempURLs.append(url)
        }
        defer { tempURLs.forEach { try? FileManager.default.removeItem(at: $0) } }

        guard let presenter = topViewController() else { return .failure(SaveError.noPresenter) }
        let picker = UIDocumentPickerViewController(forExporting: tempURLs, asCopy: true)
        let delegate = DelegateBox()
        picker.delegate = delegate
        if let popover = picker.popoverPresentationController {
            popover.sourceView = presenter.view
            popover.sourceRect = presenter.view.bounds
        }

        // 先挂好回调再 present，避免用户操作过快导致漏回调
        return await withCheckedContinuation { cont in
            delegate.onFinish = { cont.resume(returning: $0) }
            presenter.present(picker, animated: true)
        }
    }

    /// `UIDocumentPickerViewController.delegate` 是 weak → 必须自持有直到回调结束，否则收不到回调
    private final class DelegateBox: NSObject, UIDocumentPickerDelegate {
        var onFinish: ((Result<[URL], Error>) -> Void)?
        private var selfRetain: DelegateBox?

        override init() {
            super.init()
            selfRetain = self
        }

        private func finish(_ result: Result<[URL], Error>) {
            onFinish?(result)
            onFinish = nil
            selfRetain = nil   // 回调结束才释放
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            controller.dismiss(animated: true) { [weak self] in
                self?.finish(.success(urls))
            }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            controller.dismiss(animated: true) { [weak self] in
                self?.finish(.failure(Cancelled()))
            }
        }
    }
}

// MARK: - 统一媒体保存入口（iOS 写相册 / Mac 存到指定路径）

/// 各工具统一使用的保存入口：把「写相册」与「存到指定路径」的平台差异收在这一处。
/// - iOS / iPadOS：写系统相册（保持原有体验）
/// - Mac（Designed for iPad）：弹访达「存储」对话框，存到用户指定路径
enum MediaSaver {

    enum SaveError: Error, LocalizedError {
        case encodeFailed
        case cannotReadFile

        var errorDescription: String? {
            switch self {
            case .encodeFailed:   return "图片编码失败"
            case .cannotReadFile: return "无法读取待保存的文件"
            }
        }
    }

    /// 保存图片数据。Mac 上 `ext` 决定文件名后缀（jpg / heic / png），不传则按数据推断。
    @discardableResult
    static func saveImageData(_ data: Data, suggestedName: String,
                              ext: String? = nil) async -> Result<Void, Error> {
        if ProcessInfo.processInfo.isiOSAppOnMac {
            let e = ext ?? data.imageExtension()
            let name = suggestedName.hasSuffix(".\(e)") ? suggestedName : "\(suggestedName).\(e)"
            switch await MacFileSaver.save([(data: data, fileName: name)]) {
            case .success:            return .success(())
            case .failure(let error): return .failure(error)
            }
        }
        return await ImageExporter.saveData(data, suggestedFileName: suggestedName)
    }

    /// 保存 UIImage。`asPNG` 用于需要保留透明通道的场景（如幻影坦克）。
    @discardableResult
    static func saveImage(_ image: UIImage, suggestedName: String,
                          asPNG: Bool = false, quality: Double = 0.95) async -> Result<Void, Error> {
        guard let data = asPNG ? image.pngData() : image.jpegData(compressionQuality: quality) else {
            return .failure(SaveError.encodeFailed)
        }
        return await saveImageData(data, suggestedName: suggestedName, ext: asPNG ? "png" : "jpg")
    }

    /// 批量保存多张。Mac 上只弹一次访达、一次导出全部；iOS 上逐张写相册。
    @discardableResult
    static func saveImages(_ items: [(image: UIImage, name: String)],
                           asPNG: Bool = false) async -> Result<Void, Error> {
        if ProcessInfo.processInfo.isiOSAppOnMac {
            let files: [(data: Data, fileName: String)] = items.compactMap { pair in
                guard let data = asPNG ? pair.image.pngData()
                        : pair.image.jpegData(compressionQuality: 0.95) else { return nil }
                let ext = asPNG ? "png" : "jpg"
                return (data: data,
                        fileName: pair.name.hasSuffix(".\(ext)") ? pair.name : "\(pair.name).\(ext)")
            }
            switch await MacFileSaver.save(files) {
            case .success:            return .success(())
            case .failure(let error): return .failure(error)
            }
        }
        for pair in items {
            if case .failure(let error) = await saveImage(pair.image, suggestedName: pair.name, asPNG: asPNG) {
                return .failure(error)
            }
        }
        return .success(())
    }

    /// 保存视频文件（Mac 上按原扩展名存到指定路径）
    @discardableResult
    static func saveVideo(at url: URL, suggestedName: String) async -> Result<Void, Error> {
        if ProcessInfo.processInfo.isiOSAppOnMac {
            guard let data = try? Data(contentsOf: url) else { return .failure(SaveError.cannotReadFile) }
            return await saveImageData(data, suggestedName: suggestedName,
                                       ext: url.pathExtension.isEmpty ? "mov" : url.pathExtension)
        }
        guard await PHPhotoLibrary.requestAuthAsync() else {
            return .failure(ImageExporter.ExporterError.noPhotoLibraryAuth)
        }
        return await withCheckedContinuation { cont in
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
            }) { ok, err in
                cont.resume(returning: ok
                            ? .success(())
                            : .failure(err ?? ImageExporter.ExporterError.encodeFailed))
            }
        }
    }
}

// MARK: - 保存结果提示

/// 根据保存结果生成提示文案；返回 `nil` 表示无需提示（Mac 上用户主动取消保存）。
func saveResultMessage(_ result: Result<Void, Error>,
                       success: String,
                       failurePrefix: String = "保存失败：") -> String? {
    switch result {
    case .success:
        return success
    case .failure(let error):
        if error is MacFileSaver.Cancelled { return nil }   // 用户自己取消，不打扰
        return "\(failurePrefix)\(error.localizedDescription)"
    }
}
