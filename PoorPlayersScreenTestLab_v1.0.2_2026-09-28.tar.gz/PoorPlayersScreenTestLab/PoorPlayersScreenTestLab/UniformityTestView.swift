//
//  UniformityTestView.swift
//  LivePhotoLab
//
//  「均匀度测试」工具（v2.19.34 新增）
//
//  全屏铺满单一灰阶，用来看屏幕亮度/色彩是否均匀：
//  低灰阶（5%~10%）最容易暴露背光不均、漏光、暗角；高灰阶看亮度衰减与色斑。
//  HDR 开关沿用「画面信号接收器」的 EDR / HDR10 逻辑（同一套 Metal 渲染管线）。
//

import SwiftUI

struct UniformityTestView: View {

    // MARK: 参数

    /// 灰阶等级：0...255（8bit 编码值）
    @State private var grayLevel: Double = 128
    @State private var hdrMode: ResolveHDRMode = .off
    @State private var edrGain: Double = 1.0
    @State private var peakNits: Double = 1000
    @State private var fullscreen: Bool = false

    // MARK: 数值口径

    /// 归一化灰阶 0...1（8bit 编码值 / 255）
    private var unit: Double { grayLevel / 255.0 }
    private var level: Int { Int(grayLevel.rounded()) }

    /// 与「画面信号接收器」「APL 测试」一致的 HDR 换算：0...1 灰阶 → 送进 shader 的数值
    private func outputValue(_ unit: Double) -> Float {
        switch hdrMode {
        case .off:   return Float(unit)
        case .edr:   return Float(unit * edrGain)
        case .hdr10: return Float(pqEncode(nits: unit * peakNits))
        }
    }

    /// 全屏铺满：归一化位置 (0,0)、尺寸 (1,1)
    private var fill: SIMD3<Float> {
        SIMD3<Float>(outputValue(unit), outputValue(unit), outputValue(unit))
    }

    // MARK: 主体

    var body: some View {
        ZStack {
            patternLayer
                .ignoresSafeArea()
                .contentShape(Rectangle())
                // 全屏时轻点画面恢复控制面板（此时导航栏/Tab/状态栏均已隐藏）
                .onTapGesture {
                    if fullscreen { withAnimation(.easeInOut(duration: 0.2)) { fullscreen = false } }
                }

            if !fullscreen {
                VStack {
                    Spacer(minLength: 0)
                    controlCard
                        .padding(.horizontal, 12)
                        .padding(.bottom, 8)
                }
            }
        }
        .navigationTitle("均匀度测试")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(fullscreen ? .hidden : .visible, for: .navigationBar)
        .toolbar(fullscreen ? .hidden : .visible, for: .tabBar)
        .statusBarHidden(fullscreen)
        .persistentSystemOverlays(fullscreen ? .hidden : .visible)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { fullscreen.toggle() }
                } label: {
                    Image(systemName: fullscreen
                          ? "arrow.down.right.and.arrow.up.left"
                          : "arrow.up.left.and.arrow.down.right")
                }
            }
        }
        .onAppear { UIApplication.shared.isIdleTimerDisabled = true }
        .onDisappear { UIApplication.shared.isIdleTimerDisabled = false }
    }

    // MARK: 图案

    /// 与「画面信号接收器」同一块 Metal 图案层：SDR / EDR / HDR10 全靠它
    private var patternLayer: some View {
        ResolvePatternMetalView(
            background: fill,
            foreground: fill,
            position: SIMD2<Float>(0, 0),
            size: SIMD2<Float>(1, 1),
            gamut: .srgb,
            hdrMode: hdrMode,
            peakNits: peakNits
        )
    }

    // MARK: 控制面板

    private var controlCard: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                graySection

                Divider().opacity(0.2)

                hdrSection
            }
            .padding(14)
        }
        .frame(maxHeight: 300)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }

    private var graySection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("灰阶：\(level) / 255  ·  \(String(format: "%.1f", unit * 100))%")
                .font(.caption)

            Slider(value: $grayLevel, in: 0...255, step: 1)

            // 自适应网格：窄屏（如 SE）也不会挤爆一行
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 64), spacing: 8),
                                GridItem(.adaptive(minimum: 64), spacing: 8)],
                      spacing: 8) {
                ForEach([0.0, 12.0, 26.0, 51.0, 128.0, 204.0, 255.0], id: \.self) { v in
                    Button {
                        grayLevel = v
                    } label: {
                        Text("\(Int(v))")
                            .font(.caption2)
                    }
                    .buttonStyle(.bordered)
                }
            }

            Text("低灰阶（约 5%~10%）最容易看出背光不均、漏光与暗角；高灰阶看亮度衰减与色斑。"
                 + "建议全屏后在暗环境下逐档切换观察。")
                .font(.caption2)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var hdrSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("HDR 输出", systemImage: "sun.max")
                .font(.subheadline)

            Picker("HDR", selection: $hdrMode) {
                ForEach(ResolveHDRMode.allCases) { Text($0.rawValue).tag($0) }
            }
            .pickerStyle(.segmented)

            if hdrMode == .edr {
                HStack(spacing: 8) {
                    Text("增益").font(.caption).foregroundColor(.secondary)
                    Slider(value: $edrGain, in: 1...max(8, UIScreen.main.potentialEDRHeadroom), step: 0.1)
                    Text("\(edrGain, specifier: "%.1f")×")
                        .font(.caption)
                        .frame(width: 46)
                }
                HStack(spacing: 8) {
                    Text("当前 headroom \(UIScreen.main.currentEDRHeadroom, specifier: "%.2f")×")
                        .font(.caption2)
                        .foregroundColor(.orange)
                    Button("拉满") { edrGain = UIScreen.main.currentEDRHeadroom }
                        .font(.caption2)
                }
                Text("headroom 由系统动态给出（受系统亮度、原彩、温度影响）。超过它会被钳制，再拉高也不会更亮。")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }

            if hdrMode == .hdr10 {
                Picker("峰值亮度", selection: $peakNits) {
                    Text("400 nit").tag(400.0)
                    Text("1000 nit").tag(1000.0)
                    Text("4000 nit").tag(4000.0)
                    Text("10000 nit").tag(10000.0)
                }
                .pickerStyle(.segmented)
                Text("PQ 编码 + HDR10 元数据：灰阶百分比 × 峰值亮度即该档对应的绝对亮度（BT.2020 PQ）。")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
    }
}
