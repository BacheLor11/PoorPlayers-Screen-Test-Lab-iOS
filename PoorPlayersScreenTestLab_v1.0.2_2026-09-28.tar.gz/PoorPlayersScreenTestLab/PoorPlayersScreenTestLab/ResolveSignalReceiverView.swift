//
//  ResolveSignalReceiverView.swift
//  LivePhotoLab
//
//  「穷玩组屏幕测试工具箱」— 画面信号接收器（Resolve XML 协议）
//  移植自 PoorPlayers 穷玩组「穷玩组屏幕工具箱」安卓版（已获原作者授权）
//  原作者 B 站：https://space.bilibili.com/326251695
//

import SwiftUI

/// 画面信号接收器：接收 CalMAN / ColourSpace 下发的图案指令并全屏显示
struct ResolveSignalReceiverView: View {

    @StateObject private var service = ResolveSignalService()
    @State private var mode: ResolveSignalService.Mode = .server
    @State private var portText: String = "20002"
    @State private var hostText: String = ""
    @State private var fullscreen: Bool = false

    // 色域与 HDR（EDR / HDR10）
    @State private var gamut: ResolveGamut = .srgb
    @State private var hdrMode: ResolveHDRMode = .off
    @State private var sdrRenderMode: ResolveSDRRenderMode = .software
    @State private var hdrGain: Double = 1.0
    @State private var peakNits: Double = 1000
    @State private var showRawLogs: Bool = false
    @State private var showTips: Bool = false

    var body: some View {
        ZStack {
            patternLayer
                .ignoresSafeArea()
                .contentShape(Rectangle())
                // 全屏模式下轻点画面即恢复控制面板（此时导航栏/状态栏/Tab 均已隐藏）
                .onTapGesture {
                    if fullscreen { withAnimation(.easeInOut(duration: 0.2)) { fullscreen = false } }
                }

            if !fullscreen {
                VStack {
                    Spacer(minLength: 0)
                    controlCard
                        .padding(.horizontal, 12)
                        .padding(.bottom, 8)
                }
            }
        }
        .navigationTitle("画面信号接收器")
        .navigationBarTitleDisplayMode(.inline)
        // 全屏：状态栏 / 导航栏 / 底部 Tab / Home 指示条一并隐藏，避免干扰探头测量
        .toolbar(fullscreen ? .hidden : .visible, for: .navigationBar)
        .toolbar(fullscreen ? .hidden : .visible, for: .tabBar)
        .statusBarHidden(fullscreen)
        .persistentSystemOverlays(fullscreen ? .hidden : .visible)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { fullscreen.toggle() }
                } label: {
                    Image(systemName: fullscreen ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right")
                }
            }
        }
        .sheet(isPresented: $showRawLogs) { rawLogSheet }
        .onAppear { UIApplication.shared.isIdleTimerDisabled = true }
        .onDisappear {
            UIApplication.shared.isIdleTimerDisabled = false
            service.stop()
        }
    }

    // MARK: 图案渲染

    /// 图案层：SDR + 图片模式交给系统图像管线；其余（含 HDR）由 Metal 渲染
    private var patternLayer: some View {
        ZStack {
            if hdrMode == .off && sdrRenderMode == .image {
                imagePatternLayer
            } else {
                ResolvePatternMetalView(
                    background: backgroundRGB,
                    foreground: foregroundRGB,
                    position: windowPosition,
                    size: windowSize,
                    gamut: gamut,
                    hdrMode: hdrMode,
                    peakNits: peakNits
                )
            }

            if service.frame == nil {
                VStack(spacing: 10) {
                    Image(systemName: "antenna.radiowaves.left.and.right")
                        .font(.system(size: 34))
                    Text("等待校色软件下发图案")
                        .font(.subheadline)
                    Text("兼容 CalMAN / ColourSpace 的 Resolve XML 协议")
                        .font(.caption2)
                }
                .foregroundColor(.white.opacity(0.8))
            }
        }
    }

    // MARK: 图片 SDR（系统图像管线）

    /// 把图案渲染成标准 SDR 图片后交给系统图像管线显示（区别于 Metal 直接绘制）
    private var imagePatternLayer: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                Image(uiImage: backgroundImage)
                    .resizable()
                    .frame(width: geo.size.width, height: geo.size.height)

                if service.frame?.window != nil {
                    Image(uiImage: foregroundImage)
                        .resizable()
                        .frame(width: geo.size.width * CGFloat(windowSize.x),
                               height: geo.size.height * CGFloat(windowSize.y))
                        .offset(x: geo.size.width * CGFloat(windowPosition.x),
                                y: geo.size.height * CGFloat(windowPosition.y))
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .ignoresSafeArea()
    }

    private var backgroundImage: UIImage {
        guard let frame = service.frame else { return solidImage(0, 0, 0) }
        let unit = ResolveRectangle.rgbUnit(frame.background.effectiveColor, bits: frame.background.bits)
        return solidImage(unit.r, unit.g, unit.b)
    }

    private var foregroundImage: UIImage {
        guard let window = service.frame?.window else { return solidImage(0, 0, 0) }
        let unit = ResolveRectangle.rgbUnit(window.effectiveColor, bits: window.bits)
        return solidImage(unit.r, unit.g, unit.b)
    }

    /// 生成一张纯色小图（8×8，显示时拉伸即可）
    ///
    /// 关键：必须生成**带色彩空间标记**的 CGImage。
    /// 早先用 UIGraphicsImageRenderer 绘制时，其位图上下文固定为 sRGB，
    /// 且 preferredRange = .standard 会强制钳制 —— P3 / BT.2020 的数值在绘制阶段
    /// 就被转换并钳回 sRGB，导致切换色域看不出任何差别。
    /// 改为直接用 CGContext 以所选色彩空间建图，图片自带色域标签，
    /// 交给系统图像管线显示时才会按对应色域解释；8 bit 位图天然钳制在 SDR 范围内。
    private func solidImage(_ r: Double, _ g: Double, _ b: Double) -> UIImage {
        let space = gamut.colorSpace ?? CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
        let pixelSize = 8
        guard let context = CGContext(data: nil,
                                      width: pixelSize, height: pixelSize,
                                      bitsPerComponent: 8, bytesPerRow: 0,
                                      space: space,
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
                                          | CGBitmapInfo.byteOrder32Big.rawValue) else {
            return UIImage()
        }
        // 注意：CGContext 没有 setFillColor(space:components:) 这个重载，只能传 CGColor
        let components: [CGFloat] = [CGFloat(min(max(r, 0), 1)),
                                     CGFloat(min(max(g, 0), 1)),
                                     CGFloat(min(max(b, 0), 1)),
                                     1]
        let cgColor = CGColor(colorSpace: space, components: components)
        context.setFillColor(cgColor ?? CGColor(red: 0, green: 0, blue: 0, alpha: 1))
        context.fill(CGRect(x: 0, y: 0, width: pixelSize, height: pixelSize))
        guard let cgImage = context.makeImage() else { return UIImage() }
        return UIImage(cgImage: cgImage)
    }

    // MARK: 送往 shader 的颜色与几何

    /// 按当前 HDR 模式，把 0...1 的图案颜色换算成送进 shader 的数值
    private func outputRGB(_ unit: (r: Double, g: Double, b: Double)) -> SIMD3<Float> {
        switch hdrMode {
        case .off:
            return SIMD3<Float>(Float(unit.r), Float(unit.g), Float(unit.b))
        case .edr:
            let gain = Float(hdrGain)
            return SIMD3<Float>(Float(unit.r) * gain, Float(unit.g) * gain, Float(unit.b) * gain)
        case .hdr10:
            // 0...1 → 目标 nit（按峰值亮度缩放）→ PQ 编码
            return SIMD3<Float>(Float(pqEncode(nits: unit.r * peakNits)),
                                Float(pqEncode(nits: unit.g * peakNits)),
                                Float(pqEncode(nits: unit.b * peakNits)))
        }
    }

    private var backgroundRGB: SIMD3<Float> {
        guard let frame = service.frame else { return .zero }
        return outputRGB(ResolveRectangle.rgbUnit(frame.background.effectiveColor, bits: frame.background.bits))
    }

    private var foregroundRGB: SIMD3<Float> {
        guard let window = service.frame?.window else { return .zero }
        return outputRGB(ResolveRectangle.rgbUnit(window.effectiveColor, bits: window.bits))
    }

    private var windowPosition: SIMD2<Float> {
        guard let window = service.frame?.window, window.position.count >= 2 else { return .zero }
        return SIMD2<Float>(window.position[0], window.position[1])
    }

    private var windowSize: SIMD2<Float> {
        guard let window = service.frame?.window, window.size.count >= 2 else { return SIMD2<Float>(1, 1) }
        return SIMD2<Float>(window.size[0], window.size[1])
    }

    // MARK: 控制面板

    private var controlCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            statusRow
            Divider().opacity(0.2)
            Picker("模式", selection: $mode) {
                ForEach(ResolveSignalService.Mode.allCases) { Text($0.rawValue).tag($0) }
            }
            .pickerStyle(.segmented)
            .disabled(service.state.isActive)

            if mode == .server {
                serverFields
            } else {
                clientFields
            }

            actionButton

            colorControls

            VStack(alignment: .leading, spacing: 6) {
                Button {
                    withAnimation { showTips.toggle() }
                } label: {
                    Label("校色注意事项", systemImage: showTips ? "chevron.up" : "chevron.down")
                        .font(.caption)
                }
                if showTips { tipsContent }

                Button {
                    showRawLogs = true
                } label: {
                    Label("原始 XML 报文（\(service.logs.count)）", systemImage: "doc.text.magnifyingglass")
                        .font(.caption)
                }
            }
        }
        .padding(14)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }

    private var statusRow: some View {
        HStack(spacing: 8) {
            Circle()
                .fill(statusColor)
                .frame(width: 9, height: 9)
            Text(statusText)
                .font(.caption)
                .foregroundColor(.primary)
            Spacer()
            Text("已收 \(service.receivedCount)")
                .font(.caption2)
                .foregroundColor(.secondary)
        }
    }

    private var serverFields: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Text("端口")
                    .font(.caption)
                    .foregroundColor(.secondary)
                TextField("20002", text: $portText)
                    .keyboardType(.numberPad)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 110)
            }
            if let ip = ResolveNetworkUtils.localIPv4() {
                Text("本机 IP：\(ip)")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                    .textSelection(.enabled)
            } else {
                Text("未取到本机 IP（请连接 Wi-Fi）")
                    .font(.caption2)
                    .foregroundColor(.orange)
            }
        }
    }

    private var clientFields: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Text("主机")
                    .font(.caption)
                    .foregroundColor(.secondary)
                TextField("192.168.1.10", text: $hostText)
                    .keyboardType(.decimalPad)
                    .textFieldStyle(.roundedBorder)
                    .autocapitalization(.none)
            }
            HStack(spacing: 8) {
                Text("端口")
                    .font(.caption)
                    .foregroundColor(.secondary)
                TextField("20002", text: $portText)
                    .keyboardType(.numberPad)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 110)
            }
        }
    }

    /// 色域切换（sRGB / Display P3）+ HDR（EDR 扩展亮度）开关
    private var colorControls: some View {
        VStack(alignment: .leading, spacing: 8) {
            Divider().opacity(0.2)
            Label("色域与 HDR", systemImage: "sun.max")
                .font(.caption.weight(.semibold))

            Picker("HDR", selection: $hdrMode) {
                ForEach(ResolveHDRMode.allCases) { Text($0.rawValue).tag($0) }
            }
            .pickerStyle(.segmented)

            if hdrMode == .off {
                Picker("SDR 渲染", selection: $sdrRenderMode) {
                    ForEach(ResolveSDRRenderMode.allCases) { Text($0.rawValue).tag($0) }
                }
                .pickerStyle(.segmented)
                Text(sdrRenderMode == .image
                     ? "先渲染成标准 SDR 图片，再交给系统图像管线显示（会经过系统的 SDR 钳制与色彩管理）"
                     : "App 直接以 Metal 绘制，数值与色彩空间完全由本工具掌控")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }

            if hdrMode == .edr {
                HStack(spacing: 8) {
                    Text("增益")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Slider(value: $hdrGain, in: 1...max(8, UIScreen.main.potentialEDRHeadroom), step: 0.1)
                    Text("\(hdrGain, specifier: "%.1f")×")
                        .font(.caption)
                        .frame(width: 42)
                }
                HStack(spacing: 8) {
                    Text("当前 headroom \(UIScreen.main.currentEDRHeadroom, specifier: "%.2f")×")
                        .font(.caption2)
                        .foregroundColor(.orange)
                    Button("拉满") { hdrGain = UIScreen.main.currentEDRHeadroom }
                        .font(.caption2)
                }
                Text("headroom 由系统动态给出（受系统亮度、原彩、温度影响）。超过它会被钳制，再拉高也不会更亮；要更亮请切到 HDR10，或把系统亮度拉满。")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }

            if hdrMode == .hdr10 {
                Picker("峰值亮度", selection: $peakNits) {
                    Text("1000 nit").tag(1000.0)
                    Text("4000 nit").tag(4000.0)
                    Text("10000 nit").tag(10000.0)
                }
                .pickerStyle(.segmented)
                Text("PQ 编码 + HDR10 元数据：图案 100% 白即对应所选峰值亮度（BT.2020 PQ 色彩空间）。")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }

            Picker("色域", selection: $gamut) {
                ForEach(ResolveGamut.allCases) { Text($0.rawValue).tag($0) }
            }
            .pickerStyle(.segmented)
            .disabled(hdrMode != .off)

            if hdrMode != .off {
                Text("EDR / HDR10 使用 HDR 专用色彩空间，色域选项此时不生效")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
    }

    private var actionButton: some View {
        Button {
            if service.state.isActive {
                service.stop()
            } else {
                guard let port = UInt16(portText.trimmingCharacters(in: .whitespaces)) else { return }
                if mode == .server {
                    service.startServer(port: port)
                } else {
                    let host = hostText.trimmingCharacters(in: .whitespaces)
                    guard !host.isEmpty else { return }
                    service.connect(host: host, port: port)
                }
            }
        } label: {
            Text(service.state.isActive ? "停止" : (mode == .server ? "开始监听" : "连接"))
                .font(.subheadline.weight(.medium))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 9)
                .background(service.state.isActive ? Color.red.opacity(0.85) : Color.accentColor,
                            in: RoundedRectangle(cornerRadius: 10))
                .foregroundColor(.white)
        }
        .buttonStyle(.plain)
    }

    private var tipsContent: some View {
        VStack(alignment: .leading, spacing: 4) {
            tip("关闭「原彩显示 True Tone」与「夜览 Night Shift」，否则色温会被系统偏移")
            tip("关闭「自动亮度」，手动固定亮度后再开始测量")
            tip("保持本页常亮前台，息屏或切后台会中断连接")
            tip("全屏模式下轻点画面即可调出控制面板")
            tip("首次监听需在弹窗中允许「本地网络」权限")
            tip("默认端口 20002（与原版一致），可在上方修改")
        }
        .font(.caption2)
        .foregroundColor(.secondary)
        .transition(.opacity)
    }

    private func tip(_ text: String) -> some View {
        Label(text, systemImage: "exclamationmark.circle")
            .labelStyle(.titleAndIcon)
            .fixedSize(horizontal: false, vertical: true)
    }

    // MARK: 状态展示

    private var statusText: String {
        switch service.state {
        case .idle: return "未连接"
        case .listening(let port): return "监听中 · 端口 \(port)"
        case .connecting: return "连接中…"
        case .connected(let desc): return desc
        case .failed(let message): return "失败：\(message)"
        }
    }

    private var statusColor: Color {
        switch service.state {
        case .idle: return .gray
        case .listening, .connecting: return .orange
        case .connected: return .green
        case .failed: return .red
        }
    }

    // MARK: 原始报文

    private var rawLogSheet: some View {
        NavigationStack {
            List {
                if service.logs.isEmpty {
                    Text("暂无报文")
                        .foregroundColor(.secondary)
                } else {
                    ForEach(service.logs) { entry in
                        VStack(alignment: .leading, spacing: 5) {
                            HStack(spacing: 6) {
                                Text("变体 \(entry.variant)")
                                    .font(.caption2.weight(.semibold))
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(Color.accentColor.opacity(0.15), in: Capsule())
                                Text(entry.date.formatted(.dateTime.hour().minute().second()))
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                            }
                            Text(entry.summary)
                                .font(.caption2)
                                .foregroundColor(.secondary)
                            Text(entry.rawXML)
                                .font(.system(size: 10, design: .monospaced))
                                .textSelection(.enabled)
                        }
                        .padding(.vertical, 3)
                    }
                }
            }
            .navigationTitle("原始报文")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("清空") { service.clearLogs() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") { showRawLogs = false }
                }
            }
        }
    }
}
