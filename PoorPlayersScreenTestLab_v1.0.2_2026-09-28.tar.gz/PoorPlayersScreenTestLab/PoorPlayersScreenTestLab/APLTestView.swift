//
//  APLTestView.swift
//  LivePhotoLab
//
//  「APL 测试」工具（v2.19.32 新增）
//
//  玩法：读取当前屏幕分辨率，在屏幕正中渲染一块**与屏幕等比**的白色矩形，
//  拖动滑块调整矩形大小，用来目视/测量屏幕有效显示区域与四周边距（屏占比）。
//  HDR 开关沿用「画面信号接收器」的 EDR / HDR10 逻辑（同一套 Metal 渲染管线）；
//  导出 HDR 图片复用「照片 HDR 拓展」的 Gain Map 写出链路（HDRGainMapExporter）。
//

import SwiftUI
import CoreImage

struct APLTestView: View {

    // MARK: 参数

    /// 矩形宽度占屏幕宽度的百分比（高度按屏幕比例自动推导）
    @State private var widthPercent: Double = 60
    @State private var hdrMode: ResolveHDRMode = .off
    @State private var edrGain: Double = 1.0
    @State private var peakNits: Double = 1000
    @State private var fullscreen: Bool = false
    @State private var showExport: Bool = false
    @State private var statusText: String = ""

    // MARK: 屏幕与几何

    /// 屏幕逻辑尺寸（点）
    private var screenPoints: CGSize { UIScreen.main.bounds.size }
    /// 屏幕物理像素尺寸
    private var screenNative: CGSize { UIScreen.main.nativeBounds.size }
    /// 屏幕宽高比（点口径）
    private var aspect: Double {
        screenPoints.height > 0 ? screenPoints.width / screenPoints.height : 1
    }

    /// 矩形归一化宽 / 高（相对整屏）
    ///
    /// ⚠️ shader 里的 uv 是「分别按各自边长归一化」的（x÷屏宽、y÷屏高），
    /// 所以要让矩形与屏幕同比例，归一化宽高必须**相等**（都等于占宽比 f）：
    ///   w = f·W，h = f·H  ⟹  w/W = h/H = f
    /// 绝不能写成 rectH = rectW / aspect——那在 19.5:9 的手机上会把矩形
    /// 拉成「宽的 2.16 倍高」，变成又瘦又长。
    private var rectW: Double { widthPercent / 100.0 }
    private var rectH: Double { rectW }
    /// 矩形左上角归一化坐标（以屏幕左上为原点）
    private var rectPos: SIMD2<Float> {
        SIMD2<Float>(Float((1 - rectW) / 2), Float((1 - rectH) / 2))
    }
    private var rectSize: SIMD2<Float> {
        SIMD2<Float>(Float(rectW), Float(rectH))
    }

    /// 与「画面信号接收器」一致的 HDR 换算：0...1 白 → 送进 shader 的数值
    private func outputValue(_ unit: Double) -> Float {
        switch hdrMode {
        case .off:
            return Float(unit)
        case .edr:
            return Float(unit * edrGain)
        case .hdr10:
            return Float(pqEncode(nits: unit * peakNits))
        }
    }

    private var foreground: SIMD3<Float> {
        SIMD3<Float>(outputValue(1), outputValue(1), outputValue(1))
    }
    private var background: SIMD3<Float> { SIMD3<Float>(0, 0, 0) }

    // MARK: 主体

    var body: some View {
        ZStack {
            patternLayer
                .ignoresSafeArea()
                .contentShape(Rectangle())
                // 全屏时轻点画面恢复控制面板（此时导航栏/Tab/状态栏均已隐藏）
                .onTapGesture {
                    if fullscreen { withAnimation(.easeInOut(duration: 0.2)) { fullscreen = false } }
                }

            if !fullscreen {
                VStack {
                    Spacer(minLength: 0)
                    controlCard
                        .padding(.horizontal, 12)
                        .padding(.bottom, 8)
                }
            }
        }
        .navigationTitle("APL 测试")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(fullscreen ? .hidden : .visible, for: .navigationBar)
        .toolbar(fullscreen ? .hidden : .visible, for: .tabBar)
        .statusBarHidden(fullscreen)
        .persistentSystemOverlays(fullscreen ? .hidden : .visible)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { fullscreen.toggle() }
                } label: {
                    Image(systemName: fullscreen
                          ? "arrow.down.right.and.arrow.up.left"
                          : "arrow.up.left.and.arrow.down.right")
                }
            }
        }
        .sheet(isPresented: $showExport) { exportSheet }
        .onAppear { UIApplication.shared.isIdleTimerDisabled = true }
        .onDisappear { UIApplication.shared.isIdleTimerDisabled = false }
    }

    // MARK: 图案

    /// 与「画面信号接收器」同一块 Metal 图案层：SDR / EDR / HDR10 全靠它
    private var patternLayer: some View {
        ResolvePatternMetalView(
            background: background,
            foreground: foreground,
            position: rectPos,
            size: rectSize,
            gamut: .srgb,
            hdrMode: hdrMode,
            peakNits: peakNits
        )
    }

    // MARK: 控制面板

    private var controlCard: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                screenInfoRow

                Divider().opacity(0.2)

                sizeSection

                Divider().opacity(0.2)

                hdrSection

                Button {
                    showExport = true
                } label: {
                    Label("导出图片", systemImage: "square.and.arrow.up")
                        .font(.subheadline.weight(.medium))
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)

                if !statusText.isEmpty {
                    Text(statusText)
                        .font(.caption2)
                        .foregroundColor(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding(14)
        }
        .frame(maxHeight: 320)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }

    private var screenInfoRow: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("屏幕：\(Int(screenPoints.width)) × \(Int(screenPoints.height)) pt"
                 + "  ·  \(screenNative.width) × \(screenNative.height) px")
                .font(.caption)
            Text("比例 \(String(format: "%.3f", aspect)) : 1（矩形保持同比例）")
                .font(.caption2)
                .foregroundColor(.secondary)
        }
    }

    private var sizeSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("APL 尺寸：占宽 \(String(format: "%.0f", widthPercent))%"
                 + "  ·  面积占屏 \(String(format: "%.1f", rectW * rectH * 100))%")
                .font(.caption)
            Slider(value: $widthPercent, in: 1...100, step: 1)
            // 自适应网格：窄屏（如 SE）也不会挤爆一行
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 64), spacing: 8),
                                GridItem(.adaptive(minimum: 64), spacing: 8)],
                      spacing: 8) {
                ForEach([1.0, 25.0, 50.0, 75.0, 100.0], id: \.self) { p in
                    Button("\(Int(p))%") { widthPercent = p }
                        .font(.caption2)
                        .buttonStyle(.bordered)
                }
            }
            Text("矩形尺寸（物理像素）：\(Int(screenNative.width * rectW)) × \(Int(screenNative.height * rectH))")
                .font(.caption2)
                .foregroundColor(.secondary)
        }
    }

    private var hdrSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("HDR 输出", systemImage: "sun.max")
                .font(.subheadline)

            Picker("HDR", selection: $hdrMode) {
                ForEach(ResolveHDRMode.allCases) { Text($0.rawValue).tag($0) }
            }
            .pickerStyle(.segmented)

            if hdrMode == .edr {
                HStack(spacing: 8) {
                    Text("增益").font(.caption).foregroundColor(.secondary)
                    Slider(value: $edrGain, in: 1...max(8, UIScreen.main.potentialEDRHeadroom), step: 0.1)
                    Text("\(edrGain, specifier: "%.1f")×")
                        .font(.caption)
                        .frame(width: 46)
                }
                HStack(spacing: 8) {
                    Text("当前 headroom \(UIScreen.main.currentEDRHeadroom, specifier: "%.2f")×")
                        .font(.caption2)
                        .foregroundColor(.orange)
                    Button("拉满") { edrGain = UIScreen.main.currentEDRHeadroom }
                        .font(.caption2)
                }
                Text("headroom 由系统动态给出（受系统亮度、原彩、温度影响）。超过它会被钳制，再拉高也不会更亮。")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }

            if hdrMode == .hdr10 {
                Picker("峰值亮度", selection: $peakNits) {
                    Text("400 nit").tag(400.0)
                    Text("1000 nit").tag(1000.0)
                    Text("4000 nit").tag(4000.0)
                    Text("10000 nit").tag(10000.0)
                }
                .pickerStyle(.segmented)
                Text("PQ 编码 + HDR10 元数据：矩形 100% 白即对应所选峰值亮度（BT.2020 PQ 色彩空间）。")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
    }

    // MARK: 导出

    private var exportSheet: some View {
        NavigationStack {
            List {
                Section {
                    Button {
                        exportSDR()
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("导出 SDR 图片（PNG）")
                                .font(.body)
                            Text("普通动态范围，按屏幕物理像素输出黑底白矩形")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                } header: {
                    Text("导出为普通图片")
                }

                Section {
                    Button {
                        exportHDR()
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("导出 HDR 图片（HEIC + Gain Map）")
                                .font(.body)
                            Text("复用「照片 HDR 拓展」的 Gain Map 封装，HDR 屏幕上可见亮度扩展")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                } header: {
                    Text("导出为 HDR 图片")
                } footer: {
                    Text(statusText.isEmpty ? "导出尺寸：\(Int(screenNative.width)) × \(Int(screenNative.height)) px"
                                            : statusText)
                        .font(.caption2)
                }
            }
            .navigationTitle("导出 APL 图片")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") { showExport = false }
                }
            }
        }
    }

    /// 生成黑底白矩形图案（按屏幕物理像素）
    /// - 与主屏渲染保持一致：色域用 sRGB，矩形与屏幕同比例（归一化宽高相等）
    private func patternContext(width: Int, height: Int) -> CGContext? {
        let space = CGColorSpace(name: CGColorSpace.sRGB)
            ?? CGColorSpaceCreateDeviceRGB()
        guard let ctx = CGContext(data: nil,
                                  width: width, height: height,
                                  bitsPerComponent: 8, bytesPerRow: 0,
                                  space: space,
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
                                      | CGBitmapInfo.byteOrder32Big.rawValue) else { return nil }
        // 注意：iOS 的 CGColor 没有白色快捷构造，且片段构造器在某些空间下会返回 nil，
        // 这里直接用 setFillColor(.components:) —— 按上下文的 sRGB 空间解释
        ctx.setFillColor(red: 0, green: 0, blue: 0, alpha: 1)
        ctx.fill(CGRect(x: 0, y: 0, width: width, height: height))

        let rw = CGFloat(width) * rectW
        let rh = CGFloat(height) * rectH
        let rx = (CGFloat(width) - rw) / 2
        let ry = (CGFloat(height) - rh) / 2
        ctx.setFillColor(red: 1, green: 1, blue: 1, alpha: 1)
        ctx.fill(CGRect(x: rx, y: ry, width: rw, height: rh))
        return ctx
    }

    private func patternImage() -> UIImage? {
        let w = Int(screenNative.width), h = Int(screenNative.height)
        guard w > 0, h > 0, let ctx = patternContext(width: w, height: h),
              let cg = ctx.makeImage() else { return nil }
        return UIImage(cgImage: cg)
    }

    private func fileName(ext: String) -> String {
        let stamp = DateFormatter(); stamp.dateFormat = "yyyyMMdd_HHmmss"
        return "APL_\(Int(widthPercent))%_\(stamp.string(from: Date())).\(ext)"
    }

    private func exportSDR() {
        guard let img = patternImage() else {
            statusText = "生成图片失败"
            return
        }
        guard let data = img.pngData() else {
            statusText = "PNG 编码失败"
            return
        }
        Task { @MainActor in
            switch await ImageExporter.saveData(data, suggestedFileName: fileName(ext: "png")) {
            case .success:
                statusText = "已保存 SDR 图片（PNG）"
            case .failure(let err):
                statusText = "保存失败：\(err.localizedDescription)"
            }
        }
    }

    private func exportHDR() {
        let w = Int(screenNative.width), h = Int(screenNative.height)
        guard w > 0, h > 0 else { statusText = "读取屏幕尺寸失败"; return }
        guard let ctx = patternContext(width: w, height: h), let cg = ctx.makeImage() else {
            statusText = "生成图案失败"
            return
        }
        let space = CGColorSpace(name: CGColorSpace.sRGB)!
        // 增益图：矩形内满增益、背景保持基础灰（纯黑底不会被提亮）
        let rw = CGFloat(w) * rectW
        let rh = CGFloat(h) * rectH
        let rect = CGRect(x: (CGFloat(w) - rw) / 2, y: (CGFloat(h) - rh) / 2, width: rw, height: rh)
        guard let gainMap = HDRGainMapExporter.rectGainMap(width: w, height: h, rect: rect, base: 0.2) else {
            statusText = "生成增益图失败"
            return
        }
        // 主图统一到 sRGB（DeviceRGB 不是 HEIF 支持的色彩空间，会报 unsupportedColorSpace）
        var sdrCI = CIImage(cgImage: cg)
        if let cs = sdrCI.colorSpace, !CFEqual(cs, space) {
            if let toWorking = sdrCI.matchedToWorkingSpace(from: cs),
               let matched = toWorking.matchedFromWorkingSpace(to: space) {
                sdrCI = matched
            }
        }
        let (data, diag) = HDRGainMapExporter.writeGainMapHEIC(
            sdr: sdrCI,
            gainMap: gainMap,
            colorSpace: space,
            maxHeadroom: 5.0,
            quality: 0.85)
        guard let data else { statusText = diag; return }
        statusText = diag
        Task { @MainActor in
            switch await ImageExporter.saveData(data, suggestedFileName: fileName(ext: "heic")) {
            case .success:
                statusText += "\n已保存 HDR 图片（HEIC）"
            case .failure(let err):
                statusText += "\n保存失败：\(err.localizedDescription)"
            }
        }
    }
}
