//
//  FpsFlickerView.swift
//  LivePhotoLab
//
//  「FPS Flicker」工具（v2.19.39 新增）
//
//  原版穷玩组工具箱没有独立的 FPS Flicker 页（最接近的是「运动测试」的 FPS 监视器），
//  本工具按需求自研：
//    · 背景灰度滑块（0~255）——全屏铺该灰度
//    · 目标刷新率滑块（24~120）——CADisplayLink preferredFrameRateRange 锁频
//      （依赖 Info.plist CADisableMinimumFrameDurationOnPhone，v2.19.28 已声明）
//    · 自动轮换（新功能）：手动设置两个或多个目标刷新率序列，按设定间隔自动切换，
//      用于观察刷新率切换瞬间的闪烁 / 亮度抖动（LTPO 切档、PWM 相互作用等）
//
//  每帧强制提交的实现：交替赋值两个组件值相同、实例不同的 CGColor 给
//  layer.backgroundColor——Core Animation 对相同指针会跳过提交，指针不同则
//  每帧都提交，保证显示管线持续按目标 Hz 刷新（这正是 flicker 观察的前提）。
//

import SwiftUI
import UIKit

// MARK: - 渲染层（CADisplayLink 锁频 + 每帧提交）

final class FpsFlickerUIView: UIView {

    private var displayLink: CADisplayLink?
    private var lastTime: CFTimeInterval = 0
    private var measuredFps: Double = 0
    private var lastFpsReport: CFTimeInterval = 0
    private var frameIndex: Int = 0
    private var switchAnchor: CFTimeInterval = 0
    private var colorA: CGColor?
    private var colorB: CGColor?

    // 参数
    var bgGray: Int = 51 {
        didSet { rebuildColors() }
    }
    var targetHz: Int = 60 {
        didSet {
            guard oldValue != targetHz, let link = displayLink else { return }
            applyFrameRate(link)
        }
    }
    var autoHzList: [Int] = [60, 120]
    var autoInterval: Double = 2
    var autoOn: Bool = false
    private var autoIndex: Int = 0
    var fpsReport: ((Double) -> Void)?
    /// 自动轮换切换到新 Hz 时回调（用于 SwiftUI 显示当前档位）
    var hzSwitched: ((Int) -> Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        rebuildColors()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        rebuildColors()
    }

    func ensureLink() {
        guard displayLink == nil else { return }
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link.add(to: .main, forMode: .common)
        displayLink = link
        applyFrameRate(link)
    }

    func setPlaying(_ playing: Bool) {
        ensureLink()
        displayLink?.isPaused = !playing
    }

    func updateParams(bgGray: Int, targetHz: Int, autoHzList: [Int], autoInterval: Double, autoOn: Bool) {
        self.bgGray = bgGray
        self.autoHzList = autoHzList
        self.autoInterval = max(0.1, autoInterval)
        // 自动模式时 targetHz 由内部轮换控制，不受理 SwiftUI 侧的值
        if !autoOn { self.targetHz = targetHz }
        if autoOn != self.autoOn {
            self.autoOn = autoOn
            autoIndex = 0
            switchAnchor = 0
            if autoOn, let hz = autoHzList.first {
                self.targetHz = hz
            }
        }
    }

    /// 显式锁定目标刷新率（与拖影测试同一套：min = max = preferred，不给系统降档空间）
    private func applyFrameRate(_ link: CADisplayLink) {
        let maxF = Float(UIScreen.main.maximumFramesPerSecond)
        let v = min(Float(max(targetHz, 1)), maxF)
        link.preferredFrameRateRange = CAFrameRateRange(minimum: v, maximum: v, preferred: v)
    }

    private func rebuildColors() {
        let v = CGFloat(bgGray) / 255.0
        // 两个组件值完全相同、实例不同的 CGColor，供 tick 交替赋值强制提交
        colorA = UIColor(red: v, green: v, blue: v, alpha: 1).cgColor
        colorB = UIColor(red: v, green: v, blue: v, alpha: 1).cgColor
        layer.backgroundColor = colorA
    }

    @objc private func tick(_ link: CADisplayLink) {
        let t = link.timestamp

        // 自动轮换：用 displayLink 时间戳计时（与帧同步，比 Timer 准）
        if autoOn, autoHzList.count > 1 {
            if switchAnchor == 0 { switchAnchor = t }
            if t - switchAnchor >= autoInterval {
                switchAnchor = t
                autoIndex = (autoIndex + 1) % autoHzList.count
                let hz = autoHzList[autoIndex]
                if hz != targetHz {
                    targetHz = hz          // didSet 会 applyFrameRate
                    applyFrameRate(link)
                }
                hzSwitched?(hz)
            }
        } else {
            switchAnchor = t
        }

        // 每帧交替两个实例（组件相同）→ 指针变化 → 每帧强制提交
        frameIndex &+= 1
        layer.backgroundColor = (frameIndex & 1) == 0 ? colorA : colorB

        // 实测 Hz（EMA 平滑，1s 限频上报）
        if lastTime > 0 {
            let dt = t - lastTime
            if dt > 0, dt < 0.5 {
                let fps = 1.0 / dt
                measuredFps = measuredFps == 0 ? fps : measuredFps * 0.9 + fps * 0.1
                if t - lastFpsReport > 1.0 {
                    lastFpsReport = t
                    let rounded = (measuredFps * 10).rounded() / 10
                    fpsReport?(rounded)
                }
            }
        }
        lastTime = t
    }
}

// MARK: - SwiftUI 桥接

struct FpsFlickerRepresentable: UIViewRepresentable {
    let bgGray: Int
    let targetHz: Int
    let autoHzList: [Int]
    let autoInterval: Double
    let autoOn: Bool
    @Binding var isPlaying: Bool
    @Binding var measuredFps: Double
    var hzSwitched: ((Int) -> Void)?

    func makeUIView(context: Context) -> FpsFlickerUIView {
        let v = FpsFlickerUIView()
        v.fpsReport = { val in
            Task { @MainActor in self.measuredFps = val }
        }
        v.hzSwitched = hzSwitched
        v.updateParams(bgGray: bgGray, targetHz: targetHz,
                       autoHzList: autoHzList, autoInterval: autoInterval, autoOn: autoOn)
        v.setPlaying(isPlaying)
        return v
    }

    func updateUIView(_ uiView: FpsFlickerUIView, context: Context) {
        uiView.hzSwitched = hzSwitched
        uiView.updateParams(bgGray: bgGray, targetHz: targetHz,
                            autoHzList: autoHzList, autoInterval: autoInterval, autoOn: autoOn)
        uiView.setPlaying(isPlaying)
    }
}

// MARK: - 主界面

struct FpsFlickerView: View {

    enum FpsMode: String, CaseIterable, Identifiable {
        case single = "单频"
        case auto = "自动轮换"
        var id: String { rawValue }
    }

    @State private var mode: FpsMode = .single
    @State private var bgGray: Double = 51
    @State private var targetHz: Double = 60
    @State private var hzList: [Int] = [60, 120]
    @State private var addHz: Double = 90
    @State private var interval: Double = 2
    @State private var isPlaying: Bool = true
    @State private var fullscreen: Bool = false
    @State private var measuredFps: Double = 0
    @State private var currentAutoHz: Int = 60

    var body: some View {
        ZStack {
            FpsFlickerRepresentable(
                bgGray: Int(bgGray),
                targetHz: Int(targetHz),
                autoHzList: hzList,
                autoInterval: interval,
                autoOn: mode == .auto,
                isPlaying: $isPlaying,
                measuredFps: $measuredFps,
                hzSwitched: { hz in
                    Task { @MainActor in currentAutoHz = hz }
                }
            )
            .ignoresSafeArea()
            .contentShape(Rectangle())
            .onTapGesture {
                if fullscreen { withAnimation(.easeInOut(duration: 0.2)) { fullscreen = false } }
            }

            if !fullscreen {
                VStack {
                    Spacer(minLength: 0)
                    controlCard
                        .padding(.horizontal, 12)
                        .padding(.bottom, 8)
                }
            }
        }
        .navigationTitle("FPS Flicker")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(fullscreen ? .hidden : .visible, for: .navigationBar)
        .toolbar(fullscreen ? .hidden : .visible, for: .tabBar)
        .statusBarHidden(fullscreen)
        .persistentSystemOverlays(fullscreen ? .hidden : .visible)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { fullscreen.toggle() }
                } label: {
                    Image(systemName: fullscreen
                          ? "arrow.down.right.and.arrow.up.left"
                          : "arrow.up.left.and.arrow.down.right")
                }
            }
        }
        .onAppear { UIApplication.shared.isIdleTimerDisabled = true }
        .onDisappear { UIApplication.shared.isIdleTimerDisabled = false }
    }

    // MARK: 控制面板

    private var controlCard: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                Picker("模式", selection: $mode) {
                    ForEach(FpsMode.allCases) { Text($0.rawValue).tag($0) }
                }
                .pickerStyle(.segmented)

                // 状态行
                HStack(spacing: 6) {
                    let shownHz = (mode == .auto) ? currentAutoHz : Int(targetHz)
                    Text("目标 \(shownHz)Hz")
                        .font(.caption.weight(.medium))
                    Text("实测 \(String(format: "%.1f", measuredFps))Hz")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Spacer()
                    if mode == .auto, hzList.count > 1 {
                        Text("每 \(String(format: "%.1f", interval))s 轮换")
                            .font(.caption2)
                            .foregroundColor(.orange)
                    }
                }

                graySection

                if mode == .single {
                    singleHzSection
                } else {
                    autoSection
                }

                Text("以目标刷新率持续刷新纯色画面，观察该档位下的闪烁与亮度抖动；"
                     + "自动轮换则按设定间隔在多个刷新率间切换，观察切换瞬间的 flicker。"
                     + "建议暗环境、低亮度下观察。")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(14)
        }
        .frame(maxHeight: 360)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }

    // 背景灰度
    private var graySection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("背景灰度：\(Int(bgGray)) / 255")
                .font(.caption)
            Slider(value: $bgGray, in: 0...255, step: 1)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 64), spacing: 8),
                                GridItem(.adaptive(minimum: 64), spacing: 8)],
                      spacing: 8) {
                ForEach([0.0, 51.0, 128.0, 204.0, 255.0], id: \.self) { v in
                    Button("\(Int(v))") { bgGray = v }
                        .font(.caption2)
                        .buttonStyle(.bordered)
                }
            }
        }
    }

    // 单频模式的目标刷新率
    private var singleHzSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("目标刷新率：\(Int(targetHz))Hz")
                .font(.caption)
            Slider(value: $targetHz, in: 24...Double(UIScreen.main.maximumFramesPerSecond), step: 1)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 64), spacing: 8),
                                GridItem(.adaptive(minimum: 64), spacing: 8)],
                      spacing: 8) {
                ForEach([24.0, 30.0, 48.0, 60.0, 90.0, 120.0], id: \.self) { v in
                    Button("\(Int(v))Hz") { targetHz = v }
                        .font(.caption2)
                        .buttonStyle(.bordered)
                }
            }
        }
    }

    // 自动轮换：Hz 序列管理 + 切换间隔
    private var autoSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("轮换序列（点 chip 移除）：\(hzList.map(String.init).joined(separator: " → "))Hz")
                .font(.caption)

            HStack(spacing: 8) {
                Slider(value: $addHz, in: 24...Double(UIScreen.main.maximumFramesPerSecond), step: 1)
                Text("\(Int(addHz))Hz")
                    .font(.caption)
                    .frame(width: 52)
                Button {
                    hzList.append(Int(addHz))
                } label: {
                    Image(systemName: "plus.circle.fill")
                }
                .buttonStyle(.bordered)
            }

            // 已有序列（点击移除；至少保留 1 个）
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 64), spacing: 8),
                                GridItem(.adaptive(minimum: 64), spacing: 8)],
                      spacing: 8) {
                ForEach(Array(hzList.enumerated()), id: \.offset) { idx, hz in
                    Button {
                        if hzList.count > 1 { hzList.remove(at: idx) }
                    } label: {
                        Text("\(hz)Hz")
                            .font(.caption2)
                            .strikethrough(false)
                    }
                    .buttonStyle(.bordered)
                }
            }

            HStack(spacing: 8) {
                Text("切换间隔").font(.caption).foregroundColor(.secondary)
                Slider(value: $interval, in: 0.5...10, step: 0.5)
                Text("\(String(format: "%.1f", interval))s")
                    .font(.caption)
                    .frame(width: 42)
            }
        }
    }
}
