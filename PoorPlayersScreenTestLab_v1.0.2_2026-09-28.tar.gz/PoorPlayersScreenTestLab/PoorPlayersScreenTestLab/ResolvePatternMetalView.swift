//
//  ResolvePatternMetalView.swift
//  LivePhotoLab
//
//  Metal 图案渲染视图：负责 sRGB / Display P3 色域切换与 EDR(>1.0) 输出。
//  说明：EDR 无法用 SwiftUI / 普通 CALayer 实现（内容会被钳制在 SDR 1.0），
//  必须走 CAMetalLayer.wantsExtendedDynamicRangeContent，故图案层统一由 Metal 渲染。
//

import SwiftUI
import Metal
import MetalKit
import QuartzCore

// MARK: - 色域

/// 图案色域（仅 SDR 模式生效；开启 HDR 后改用扩展线性工作空间）
enum ResolveGamut: String, CaseIterable, Identifiable {
    case srgb = "sRGB"
    case displayP3 = "Display P3"
    case bt2020 = "BT.2020"

    var id: String { rawValue }

    var colorSpace: CGColorSpace? {
        switch self {
        case .srgb: return CGColorSpace(name: CGColorSpace.sRGB)
        case .displayP3: return CGColorSpace(name: CGColorSpace.displayP3)
        case .bt2020: return CGColorSpace(name: CGColorSpace.itur_2020)
        }
    }
}

/// SDR 渲染方式（对应安卓原版的 SdrRenderMode）
/// - software：App 直接用 Metal 绘制，数值与色彩空间由我们完全掌控
/// - image：渲染成一张标准 SDR 图片再交给系统图像管线显示（会经过系统的 SDR 钳制与色彩管理）
enum ResolveSDRRenderMode: String, CaseIterable, Identifiable {
    case software = "软件渲染"
    case image = "图片 SDR"
    var id: String { rawValue }
}

// MARK: - HDR 输出模式

/// HDR 输出模式
/// - off：标准 SDR，数值 0...1，按所选色域解释
/// - edr：线性扩展亮度（值 × 增益，可超过 1.0），由系统按当前 headroom 渲染
/// - hdr10：PQ(SMPTE ST 2084) 编码 + CAEDRMetadata.hdr10 元数据，按 HDR10 语义由系统 tone map
enum ResolveHDRMode: String, CaseIterable, Identifiable {
    case off = "SDR"
    case edr = "EDR"
    case hdr10 = "HDR10"
    var id: String { rawValue }
}

// MARK: - PQ 编码

/// SMPTE ST 2084 (PQ) 光电传递函数：把线性亮度(单位 nit，0...10000)编码为 0...1
/// HDR10 采用该传递函数；配合 opticalOutputScale = 10000 时，编码值 1.0 即对应 10000 nits。
func pqEncode(nits: Double) -> Double {
    let clamped = min(max(nits, 0), 10000) / 10000.0
    let m1 = 0.1593017578125
    let m2 = 78.84375
    let c1 = 0.8359375
    let c2 = 18.8515625
    let c3 = 18.6875
    let powered = pow(clamped, m1)
    let numerator = c1 + c2 * powered
    let denominator = 1 + c3 * powered
    return pow(numerator / denominator, m2)
}

// MARK: - 与 shader 共享的 Uniforms

/// 布局须与 ResolvePatternShaders.metal 中的 ResolveUniforms 一致：
/// float3(16) + float3(16) + float2(8) + float2(8) = 48 字节
struct ResolvePatternUniforms {
    var background: SIMD3<Float>
    var foreground: SIMD3<Float>
    var position: SIMD2<Float>
    var size: SIMD2<Float>
}

// MARK: - 渲染视图

struct ResolvePatternMetalView: UIViewRepresentable {

    var background: SIMD3<Float>
    var foreground: SIMD3<Float>
    var position: SIMD2<Float>
    var size: SIMD2<Float>
    var gamut: ResolveGamut
    var hdrMode: ResolveHDRMode
    var peakNits: Double

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> MTKView {
        let view = MTKView(frame: .zero)
        view.device = MTLCreateSystemDefaultDevice()
        view.delegate = context.coordinator
        // 图案是静态的：仅在数据变化时重绘，避免持续 60fps 空转
        view.isPaused = true
        view.enableSetNeedsDisplay = true
        // rgba16Float 才能承载 >1.0 的 EDR 扩展值
        view.colorPixelFormat = .rgba16Float
        view.clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 1)
        context.coordinator.prepare(view)
        return view
    }

    func updateUIView(_ view: MTKView, context: Context) {
        context.coordinator.apply(gamut: gamut, hdrMode: hdrMode, peakNits: peakNits, view: view)
        context.coordinator.uniforms = ResolvePatternUniforms(
            background: background,
            foreground: foreground,
            position: position,
            size: size
        )
        view.setNeedsDisplay()
    }

    // MARK: Coordinator

    final class Coordinator: NSObject, MTKViewDelegate {

        var uniforms = ResolvePatternUniforms(background: .zero,
                                              foreground: .zero,
                                              position: .zero,
                                              size: SIMD2<Float>(1, 1))

        private var pipeline: MTLRenderPipelineState?
        private var commandQueue: MTLCommandQueue?

        func prepare(_ view: MTKView) {
            guard let device = view.device else { return }
            commandQueue = device.makeCommandQueue()
            // makeDefaultLibrary() 返回的是可选值而非 throws，不需要 try?
            guard let library = device.makeDefaultLibrary(),
                  let vertex = library.makeFunction(name: "resolvePatternVertex"),
                  let fragment = library.makeFunction(name: "resolvePatternFragment") else { return }
            let descriptor = MTLRenderPipelineDescriptor()
            descriptor.vertexFunction = vertex
            descriptor.fragmentFunction = fragment
            descriptor.colorAttachments[0].pixelFormat = view.colorPixelFormat
            pipeline = try? device.makeRenderPipelineState(descriptor: descriptor)
        }

        func apply(gamut: ResolveGamut, hdrMode: ResolveHDRMode, peakNits: Double, view: MTKView) {
            // 注意：iOS 的 MTKView 没有 colorspace 属性（那是 macOS 独有），
            // 必须设置到其底层的 CAMetalLayer 上才会生效。
            guard let metalLayer = view.layer as? CAMetalLayer else { return }
            switch hdrMode {
            case .off:
                metalLayer.colorspace = gamut.colorSpace
                metalLayer.wantsExtendedDynamicRangeContent = false
                metalLayer.edrMetadata = nil
            case .edr:
                // 线性扩展亮度：数值可直接超过 1.0，由系统按当前 headroom 渲染
                metalLayer.colorspace = CGColorSpace(name: CGColorSpace.extendedLinearSRGB)
                metalLayer.wantsExtendedDynamicRangeContent = true
                metalLayer.edrMetadata = nil
            case .hdr10:
                // PQ 编码像素 + HDR10 元数据。opticalOutputScale = 10000：
                // 归一化像素格式下，值 1.0 对应 10000 nits（Apple 文档建议值）。
                metalLayer.colorspace = CGColorSpace(name: CGColorSpace.itur_2100_PQ)
                metalLayer.wantsExtendedDynamicRangeContent = true
                metalLayer.edrMetadata = CAEDRMetadata.isAvailable
                    ? CAEDRMetadata.hdr10(minLuminance: 0.005,
                                          maxLuminance: Float(peakNits),
                                          opticalOutputScale: 10000)
                    : nil
            }
        }

        func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}

        func draw(in view: MTKView) {
            guard let descriptor = view.currentRenderPassDescriptor,
                  let pipeline,
                  let queue = commandQueue,
                  let buffer = queue.makeCommandBuffer(),
                  let encoder = buffer.makeRenderCommandEncoder(descriptor: descriptor) else { return }
            var uniforms = self.uniforms
            let length = MemoryLayout<ResolvePatternUniforms>.stride
            encoder.setRenderPipelineState(pipeline)
            encoder.setVertexBytes(&uniforms, length: length, index: 0)
            encoder.setFragmentBytes(&uniforms, length: length, index: 0)
            encoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
            encoder.endEncoding()
            if let drawable = view.currentDrawable { buffer.present(drawable) }
            buffer.commit()
        }
    }
}
